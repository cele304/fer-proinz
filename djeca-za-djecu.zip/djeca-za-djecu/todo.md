# Todo

## Backend
1. Unit testovi
2. Selenium testovi
3. Api za slanje maila
4. Api za slanje oglasa u admin qeueu
5. Api za dohvačanje oglasa u admin queue
6. Api za odobravanje oglasa
7. Api za vraćanje oglasa na doradu
8. Api za dohvaćanje oglasa koji su vraćeni na doradu za korisnika. 

## Frontend
1. Registracija ne šalje na dobar url (treba na signup, ne signin)
2. Datum u registarciji - bilo bi super da imamo baš pravi kalendar
3. Preporučena dob u dodavanju oglasa bi trebalal biti broj (ako je teško to na frontendu staviti onda ćemo na backendu) 
4. Admin sučelje gdje vidi oglase za potvrdu


## Dokumentacija

## Deploy
1. Staviti da bude postgres baza