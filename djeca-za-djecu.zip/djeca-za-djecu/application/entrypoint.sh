#!/bin/bash
PGPASSWORD=bazepodataka psql -h db -p 5432 -U postgres -c "create database react;" && true

cd /app

mvn test
java -jar ./target/*.jar