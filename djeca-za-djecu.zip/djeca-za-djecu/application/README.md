# Springboot backend

## How to run

1. mvn clean
2. mvn package
3. java -jar target/progi-0.0.1-SNAPSHOT.jar

## How to use

1. To se database go to http://localhost:8080/h2-console and login with username: `sa` and no password
2. Best way to test backend is to use postman

## Api documentation

### Oglas

Primjer oglasa:

```json
{
  "naslov": "Darujem Triple kolica",
  "opis": "Kolica za bebe",
  "slika": null,
  "datumObjave": "2022-11-07",
  "stanjePredmeta": "NOVO",
  "predvidenaDob": "do 1 godine",
  "predivdenSpol": "UNISEX",
  "rokUpotrebe": "2022-10-07",
  "korisnik": {
    "email": "admin",
    "ime": "admin",
    "prezime": "admin"
  },
  "podkategorija":{
      "naziv": "Lego kocke",
      "kategorija": {
          "naziv": "Igračke"
      }
  }
}
```

#### GET

1. http://localhost:8080/api/v1/oglasi/{id} - dohvaća oglas s id-em

2. http://localhost:8080/api/v1/oglasi - lista svih oglasa
. 
3. http://localhost:8080/api/v1/oglasi/moji-oglasi - lista svih oglasa trenutnog korisnika

#### POST

1. http://localhost:8080/api/v1/oglasi - stvara novi oglas

---

### Korisnik

Primjer korisnika:

```json
{
  "id": 6,
  "email": "mario.markovic@gmail.com",
  "lozinka": "123456",
  "ime": "Marko",
  "prezime": "Markovic",
  "brojMobitela": "0987654321",
  "razinaOvlasti": 100,
  "djeca": [],
  "oglasi": []
}
```

#### GET

1. http://localhost:8080/api/v1/korisnik/{id} - dohvaća korisnika s id-em
2. http://localhost:8080/api/v1/korisnik - lista svih korisnika

#### POST

1. http://localhost:8080/api/v1/korisnik/signup - stvara novog korisnika
```json
  {
  "email": "mario.peric@gmail.com",
  "lozinka": "123456",
  "ime": "Mario",
  "prezime": "Markovic",
  "brojMobitela": "0987654321",
  "dijete": [{
    "spol": "M",
    "datumRodjenja": "2022-11-07"
  }],
  "adresa": {
    "grad": "Koprivnica",
    "zipcode": "48000",
    "ulica": "Ulica123"
  }
}
 ```


### TRENUTNI KORISNIK
#### GET
1. http://localhost:8080/api/v1/korisnik/me - dohvaća trenutnog korisnika
```json
{
  "email": "mario.markovic@gmail.com",
  "lozinka": null,
  "ime": "Mario",
  "prezime": "Markovic",
  "brojMobitela": "0987654321",
  "adresa": {
    "grad": "Zagreb",
    "ulica": "Trg bana Josipa Jelacica",
    "zipcode": "10000"
  },
  "dijete": [{
    "spol": "M",
    "datumRodjenja": "2022-11-07"
  }],
  "oglasi": null
}
```
2. http://localhost:8080/api/v1/korisnik/isloggedin - vraća true ako je korisnik ulogiran. Vraća 403 Forbiddedn ako nije.


* LOGIN -  POST http://localhost:8080/api/v1/korisnik/signin?email=admin&lozinka=admin
* REGISTER -  POST http://localhost:8080/api/v1/korisnik/signup, BODY:
```
 {
  "email": "mario.peric@gmail.com",
  "lozinka": "123456",
  "ime": "Mario",
  "prezime": "Markovic",
  "brojMobitela": "0987654321",
  "dijete": [{
    "spol": "M",
    "datumRodjenja": "2022-11-07"
  }],
  "adresa": {
    "grad": "Koprivnica",
    "zipcode": "48000",
    "ulica": "Ulica123"
  }
}
```
### UTIL
#### DOHVATI SVE KATEGORIJE (GET)
http://localhost:8080/api/v1/util/kategorije

#### DOHVATI SVE PODKATEGORIJE IZ NEKE KATEGORIJE (GET)
http://localhost:8080/api/v1/util/podkategorije/{ime_kategorije}



### STANJE OGLASA
1. POST
http://localhost:8080/api/v1/util/podkategorije/{ime_kategorije}
```
AKTIVAN
```

### BRISANJE OGLASA
1. DELETE
http://localhost:8080/api/v1/oglasi/{id_oglasa}



### ZATVARANJE OGLASA
1. POST
http://localhost:8080/api/v1/oglasi/zatvori/{id_oglasa}


### DAJ DOZOVLU KORISNIKU
1. POST
http://localhost:8080/api/v1/korisnik/dozvoli/{id_korisnika}
```
POTVRDENI_KORISNIK
```

### VRATI NA DORADU
1. POST
http://localhost:8080/api/v1/oglasi/dorada/{id_oglasa}

### UREDI (PONOVO POŠALJI) OGLAS
1. POST
http://localhost:8080/api/v1/oglasi/{id_korisnika}
```json
{
  "naslov": "Darujem Triple kolica",
  "opis": "Kolica za bebe",
  "slika": null,
  "datumObjave": "2022-11-07",
  "stanjePredmeta": "NOVO",
  "predvidenaDob": "do 1 godine",
  "predivdenSpol": "UNISEX",
  "rokUpotrebe": "2022-10-07",
  "korisnik": {
    "email": "admin",
    "ime": "admin",
    "prezime": "admin"
  },
  "podkategorija":{
    "naziv": "Lego kocke",
    "kategorija": {
      "naziv": "Igračke"
    }
  }
}
```
### UPDATE PROFILA KORISNIKA
1. POST
http://localhost:8080/api/v1/korisnik/update
```json
 {
  "email": "mario.peric@gmail.com",
  "lozinka": "123456",
  "ime": "Mario",
  "prezime": "Markovic",
  "brojMobitela": "0987654321",
  "dijete": [{
    "spol": "M",
    "datumRodjenja": "2022-11-07"
  }],
  "adresa": {
    "grad": "Koprivnica",
    "zipcode": "48000",
    "ulica": "Ulica123"
  }
}
```

### Lista čekanja oglasa
1. GET http://localhost:8080/api/v1/oglasi/listaCekanja


### Dohvati listu interesa
1. GET http://localhost:8080/api/v1/korisnik/getinteresi

### Dodaj u listu interesa
1. POST http://localhost:8080/api/v1/korisnik/updateinteresi
```json
["Hlače"]
```

### Makni iz listu interesa
1. DELETE http://localhost:8080/api/v1/korisnik/deleteinteresi
```json
["Hlače"]
```

### Dohvati preferirane oglase
1. GET http://localhost:8080/api/v1/oglasi/preferirani/oglasi
```json
["Lista oglasa"]
```