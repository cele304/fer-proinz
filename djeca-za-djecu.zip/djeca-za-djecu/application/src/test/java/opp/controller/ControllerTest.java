package opp.controller;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import opp.security.JwtTokenProvider;
import opp.security.MyUserDetails;
import opp.service.DijeteService;
import opp.service.KorisnikService;
import opp.service.PodKategorijaService;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import com.fasterxml.jackson.databind.ObjectMapper;



@WebMvcTest({
		UserController.class,
		KorisnikService.class,
		JwtTokenProvider.class,
		PodKategorijaService.class
})
public class ControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private KorisnikService service;

	@MockBean
	private MyUserDetails userDetails;

	@MockBean
	private DijeteService unkwon;

	@MockBean
	private PodKategorijaService serviceKategorija;

	@Test
	void frontPage() throws Exception {
		this.mvc.perform(get("/"))
				.andExpect(status().isOk());
	}

	@Test
	void loginUser() throws Exception {

		MvcResult result = mvc.perform(post("http://localhost:8080/api/v1/korisnik/signin?email=admin&lozinka=admin"))
				.andDo( MockMvcResultHandlers.print() )
				.andExpect( status().isOk() ).andReturn();


		String content = result.getResponse().getContentAsString();
		System.out.println(content);
	}

	@Test
	void singUpUser() throws Exception {

		String input = " {\n" +
				"  \"email\": \"mario.peric@gmail.com\",\n" +
				"  \"lozinka\": \"123456\",\n" +
				"  \"ime\": \"Mario\",\n" +
				"  \"prezime\": \"Markovic\",\n" +
				"  \"brojMobitela\": \"0987654321\",\n" +
				"  \"dijete\": [{\n" +
				"    \"spol\": \"M\",\n" +
				"    \"datumRodjenja\": \"2022-11-07\"\n" +
				"  }],\n" +
				"  \"adresa\": {\n" +
				"    \"grad\": \"Koprivnica\",\n" +
				"    \"zipcode\": \"48000\",\n" +
				"    \"ulica\": \"Ulica123\"\n" +
				"  }\n" +
				"}";

		MvcResult result = mvc.perform(post("/api/v1/korisnik/signup").accept( MediaType.APPLICATION_JSON)
				.content(input)
				.contentType(MediaType.APPLICATION_JSON)).andDo(MockMvcResultHandlers.print())
				.andExpect(status().isOk()).andReturn();


		String content = result.getResponse().getContentAsString();
		System.out.println(content);

	}


}
