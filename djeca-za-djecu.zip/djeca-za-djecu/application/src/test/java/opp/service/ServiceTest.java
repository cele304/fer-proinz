package opp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import opp.dto.KorisnikDTO;
import opp.dto.OglasDTO;
import opp.model.Korisnik;
import opp.model.Oglas;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest
public class ServiceTest {

	@Autowired
	protected KorisnikService serviceKorisnik;

	@Autowired
	private OglasService serviceOglas;


	@Autowired
	private ModelMapper modelMapper;

	@Test
	void korisnikCount(){
		//Postoji inicijalni korisnik admin
		Assert.assertNotEquals( 0, serviceKorisnik.findAll().size() );
	}

	@Test
	void loginService(){
		//Postoji inicijalni korisnik admin
		String token = serviceKorisnik.signin( "admin", "admin" );

		System.out.println(token);

		Assert.assertNotEquals( token, null );
	}

	@Test
	void searchByEmail(){

		Korisnik korisnik = serviceKorisnik.search( "admin" );

		Assert.assertEquals( korisnik.getEmail(), "admin" );
	}

	@Test
	void whoAmiMethod(){

		String token = serviceKorisnik.signin( "admin", "admin" );

		Korisnik korisnik = serviceKorisnik.whoami( token );

		System.out.println(korisnik.getEmail());

		Assert.assertEquals( korisnik.getEmail(), "admin" );
	}

	@Test
	void signUpService() throws JsonProcessingException {

		String input = " {\n" +
				"  \"email\": \"mario.peric@gmail.com\",\n" +
				"  \"lozinka\": \"123456\",\n" +
				"  \"ime\": \"Mario\",\n" +
				"  \"prezime\": \"Markovic\",\n" +
				"  \"brojMobitela\": \"0987654321\",\n" +
				"  \"dijete\": [{\n" +
				"    \"spol\": \"M\",\n" +
				"    \"datumRodjenja\": \"2022-11-07\"\n" +
				"  }],\n" +
				"  \"adresa\": {\n" +
				"    \"grad\": \"Koprivnica\",\n" +
				"    \"zipcode\": \"48000\",\n" +
				"    \"ulica\": \"Ulica123\"\n" +
				"  }\n" +
				"}";


		ObjectMapper objectMapper = new ObjectMapper();
		KorisnikDTO korisnikDTO = objectMapper.readValue( input, KorisnikDTO.class );

		Korisnik korisnik = modelMapper.map(korisnikDTO, Korisnik.class);

		String token = serviceKorisnik.signup( korisnik );
		serviceKorisnik.delete(korisnik.getEmail());

		Assert.assertNotEquals( token, null );

	}

	@Test
	void convertOglasFromDTO() throws JsonProcessingException {

		String input = "{\n" +
				"  \"naslov\": \"Darujem Triple kolica\",\n" +
				"  \"opis\": \"Kolica za bebe\",\n" +
				"  \"slika\": null,\n" +
				"  \"datumObjave\": \"2022-11-07\",\n" +
				"  \"stanjePredmeta\": \"NOVO\",\n" +
				"  \"predvidenaDob\": \"do 1 godine\",\n" +
				"  \"predivdenSpol\": \"UNISEX\",\n" +
				"  \"rokUpotrebe\": \"2022-10-07\",\n" +
				"  \"korisnik\": {\n" +
				"    \"email\": \"admin\",\n" +
				"    \"ime\": \"admin\",\n" +
				"    \"prezime\": \"admin\"\n" +
				"  },\n" +
				"  \"podkategorija\":{\n" +
				"      \"naziv\": \"Lego kocke\",\n" +
				"      \"kategorija\": {\n" +
				"          \"naziv\": \"Igračke\"\n" +
				"      }\n" +
				"  }\n" +
				"}\n";


		ObjectMapper objectMapper = new ObjectMapper();
		OglasDTO oglasDTO = objectMapper.readValue( input, OglasDTO.class );

		Oglas oglas = modelMapper.map(oglasDTO, Oglas.class);

		Assert.assertEquals( oglas.getNaslov(),  "Darujem Triple kolica");
		Assert.assertEquals( oglas.getOpis(),  "Kolica za bebe");
	}

}
