package opp.controller;

import javax.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
//import opp.model.AppUser;
import opp.dto.KorisnikDTO;
import opp.model.AppUserRole;
import opp.mail.EmailServiceProvider;
import opp.model.Dijete;
import opp.model.Korisnik;
import opp.model.Podkategorija;
import opp.service.DijeteService;
import opp.service.KorisnikService;
import opp.service.PodKategorijaService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import opp.dto.UserDataDTO;
import opp.dto.UserResponseDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
//import opp.service.UserService;

@RestController
@RequestMapping("/api/v1/korisnik")
@Api(tags = "users")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserController {

  @Autowired
  private KorisnikService userService;

  @Autowired
  private ModelMapper modelMapper;

  @Autowired
  private final PodKategorijaService podKategorijaService;

  @Autowired
  private DijeteService dijeteService;

//  @PostMapping("/signin")
//  @ApiOperation(value = "${UserController.signin}")
//  @ApiResponses(value = {//
//      @ApiResponse(code = 400, message = "Something went wrong"), //
//      @ApiResponse(code = 422, message = "Invalid username/password supplied")})
//  public String login(//
//      @ApiParam("Username") @RequestParam String username, //
//      @ApiParam("Password") @RequestParam String password) {
//    return userService.signin(username, password);
//  }

  @PostMapping("/signin")
  @ApiOperation(value = "${UserController.signin}")
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 422, message = "Invalid username/password supplied")})
  public String login(//
                      @ApiParam("email") @RequestParam String email, //
                      @ApiParam("lozinka") @RequestParam String lozinka) {

    String token = userService.signin(email, lozinka);

    return token;
  }



//  @PostMapping("/signup")
//  @ApiOperation(value = "${UserController.signup}")
//  @ApiResponses(value = {//
//      @ApiResponse(code = 400, message = "Something went wrong"), //
//      @ApiResponse(code = 403, message = "Access denied"), //
//      @ApiResponse(code = 422, message = "Username is already in use")})
//  public String signup(@ApiParam("Signup User") @RequestBody UserDataDTO user) {
//
//    Korisnik korisnik = modelMapper.map(user, Korisnik.class);
//
//    return userService.signup(korisnik);
//  }

  @PostMapping("/signup")
  @ApiOperation(value = "${UserController.signup}")
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 422, message = "Username is already in use")})
  public String signup(@ApiParam("Signup User") @RequestBody KorisnikDTO input) {

    Korisnik korisnik = modelMapper.map(input, Korisnik.class);

    EmailServiceProvider emailServiceProvider = new EmailServiceProvider();
    emailServiceProvider.sendMessage(korisnik.getEmail(), "Djeca za djecu", "Successful sign up!");

    List<Podkategorija> podkategorija = podKategorijaService.findAll();

    List<String> interesi = podkategorija.stream().map( s -> s.getNaziv() ).collect( Collectors.toList());

    korisnik.setInteresi( interesi );

    return userService.signup(korisnik);
  }

  @DeleteMapping(value = "/{email}")
  @ApiOperation(value = "${UserController.delete}", authorizations = { @Authorization(value="apiKey") })
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 404, message = "The user doesn't exist"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public ResponseEntity<String> delete(@ApiParam("email") @PathVariable String email) {
    if (!email.equals("admin")) {
      userService.delete(email);
      return new ResponseEntity<>("User deleted", HttpStatus.OK);
    }
    else{
      return new ResponseEntity<>("You cannot delete admin user.", HttpStatus.BAD_REQUEST);
    }
  }

  @GetMapping(value = "/{email}")
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 404, message = "The user doesn't exist"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public KorisnikDTO search(@PathVariable String email) {
    Korisnik korisnik = userService.search(email);
    KorisnikDTO dto = KorisnikDTO.of(korisnik);
    return dto;
  }
  @GetMapping(value = "")
  @ApiOperation(value = "${UserController.search}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 404, message = "The user doesn't exist"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public List<KorisnikDTO> search() {
    List<Korisnik> result = this.userService.findAll();
    List<KorisnikDTO> output = new ArrayList<>();

    for(Korisnik tmp: result){
      KorisnikDTO dto = KorisnikDTO.of(tmp);
      output.add( dto );
    }

    for(KorisnikDTO dto: output){
      if(dto.getRoles() == null){
        Korisnik tmp = this.userService.findByEmail( dto.getEmail() );
        dto.setRoles( tmp.getRoles() );
      }
    }

    return output;
  }
  @GetMapping(value = "/me")
  @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
  @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public UserResponseDTO whoami(HttpServletRequest req) {
    Korisnik korisnik = userService.whoami(req);
    UserResponseDTO korisnikDTO = modelMapper.map(korisnik, UserResponseDTO.class);

    return korisnikDTO;
  }
  @GetMapping(value = "/isloggedin")
  @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_POTVRDENI_KORISNIK') or hasRole('ROLE_NEPOTVRDENI_KORISNIK')")
  @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public boolean isLoggedIn(HttpServletRequest req) {
    return true;
  }
  @GetMapping("/refresh")
  @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_PODVRDENI_KORISNIK') or hasRole('ROLE_NEPOTVRDENI_KORISNIK')")
  public String refresh(HttpServletRequest req) {
    return userService.refresh(req.getRemoteUser());
  }

  @PostMapping(value = "dozvoli/{email}")
  @PreAuthorize("hasRole('ROLE_ADMIN')")
  @ApiOperation(value = "${UserController.search}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 404, message = "The user doesn't exist"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public ResponseEntity<KorisnikDTO> dajDozvolu(@ApiParam("email") @PathVariable String email, @RequestBody String newRole) {
    Korisnik korisnik = userService.search(email);
    if(korisnik == null){
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    korisnik.getRoles().clear();
    korisnik.getRoles().add(AppUserRole.valueOf(newRole));
    userService.saveKorisnik(korisnik);
    KorisnikDTO korisnikDTO = modelMapper.map(korisnik, KorisnikDTO.class);
    return new ResponseEntity<>(korisnikDTO, HttpStatus.OK);
  }
  @PostMapping("/update")
  @ApiOperation(value = "${UserController.signup}")
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 422, message = "Username is already in use")})
  public ResponseEntity<Korisnik> updateProfil(@ApiParam("Update") @RequestBody KorisnikDTO input, HttpServletRequest req) {
    Korisnik korisnik = modelMapper.map(input, Korisnik.class);
    Korisnik oldKorisnik = userService.whoami(req);

    oldKorisnik.setAdresa( korisnik.getAdresa() );

    Dijete dijete = null;
    try{
    dijete = dijeteService.saveDijete(korisnik.getDijete().get( 0 ) );
    }catch (Exception ignorable){

    };

    List<Dijete> djeca = new ArrayList<>();
    djeca.add( dijete );

    oldKorisnik.setDijete( djeca );

    Korisnik saved = userService.saveKorisnik(oldKorisnik);

    return new ResponseEntity<>(saved, HttpStatus.OK);
  }
  @GetMapping(value = "/getinteresi")
  @ApiResponses(value = {//
          @ApiResponse(code = 400, message = "Something went wrong"), //
          @ApiResponse(code = 403, message = "Access denied"), //
          @ApiResponse(code = 404, message = "The user doesn't exist"), //
          @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
  public ResponseEntity<List<Podkategorija>> getInteresi(HttpServletRequest req) {
    Korisnik korisnik = userService.whoami(req);
    if(korisnik == null){
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    List<String> interesi = korisnik.getInteresi();
    List<Podkategorija> interesiKategorije = new ArrayList<>();

    for(String tmp: interesi){
      interesiKategorije.add(podKategorijaService.getByNaziv(tmp));
    }

    return new ResponseEntity<>(interesiKategorije, HttpStatus.OK);
  }

  @PostMapping(value = "/updateinteresi")
  public ResponseEntity<List<Podkategorija>> updateInteresi(@RequestBody List<String> interesi, HttpServletRequest req) {
    Korisnik korisnik = userService.whoami(req);

    korisnik.getInteresi().addAll(interesi);
    userService.saveKorisnik(korisnik);
    List<Podkategorija> interesiKategorije = new ArrayList<>();

    for(String tmp: interesi){
      interesiKategorije.add(podKategorijaService.getByNaziv(tmp));
    }

    return new ResponseEntity<>(interesiKategorije, HttpStatus.OK);
  }

  @DeleteMapping(value = "/deleteinteresi")
  public ResponseEntity<List<Podkategorija>> deleteInteresi(@RequestBody List<String> interesi, HttpServletRequest req) {
    Korisnik korisnik = userService.whoami(req);

    korisnik.getInteresi().removeAll(interesi);
    userService.saveKorisnik(korisnik);
    List<Podkategorija> interesiKategorije = new ArrayList<>();

    for(String tmp: interesi){
      interesiKategorije.add(podKategorijaService.getByNaziv(tmp));
    }

    return new ResponseEntity<>(interesiKategorije, HttpStatus.OK);
  }

}
