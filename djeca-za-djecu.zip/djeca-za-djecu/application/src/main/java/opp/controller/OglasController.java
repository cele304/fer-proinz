package opp.controller;

import java.net.URI;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import javassist.NotFoundException;
import lombok.RequiredArgsConstructor;
import opp.dto.*;
import opp.model.*;
import opp.service.KategorijaService;
import opp.service.KorisnikService;
import opp.service.PodKategorijaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import opp.service.OglasService;

import org.modelmapper.ModelMapper;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/api/v1/oglasi")
@RequiredArgsConstructor
public class OglasController {

    @Autowired
    OglasService service;

    @Autowired
    KorisnikService korisnikService;

    @Autowired
    PodKategorijaService podkategorijaService;

    @Autowired
    KategorijaService kategorijaService;

    @Autowired
    private ModelMapper modelMapper;




    @GetMapping(value = "/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public Oglas getOglas(@PathVariable("id") long id) {
        Oglas oglas = service.getById(id).get();
        return oglas;
    }

    @GetMapping(value = "")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public List<Oglas> getOglasi() { return service.findAll(); }

    @PostMapping(value = "")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public ResponseEntity<Oglas> createOglas(@RequestBody OglasDTO oglasDTO) throws NotFoundException {
        PodkategorijaDTO podkategorijaDTO = oglasDTO.getPodkategorija();
        Podkategorija podkategorija = podkategorijaService.getByNaziv(podkategorijaDTO.getNaziv());
        if(podkategorija == null){
            podkategorija = modelMapper.map(podkategorijaDTO, Podkategorija.class);
            KategorijaDTO kategorijaDTO = podkategorijaDTO.getKategorija();
            Kategorija kategorija = kategorijaService.getByNaziv(kategorijaDTO.getNaziv());
            if(kategorija == null){
                kategorija = modelMapper.map(kategorijaDTO, Kategorija.class);
                kategorijaService.saveKategorija(kategorija);
            }
            podkategorija.setKategorija(kategorija);
            podkategorijaService.savePodKategorija(podkategorija);
        }
        KorisnikDTO korisnikDTO = oglasDTO.getKorisnik();
        Korisnik korisnik = korisnikService.findByEmail(korisnikDTO.getEmail());
        if(korisnik == null){
            throw new NotFoundException("Korisnik sa email-om: " + korisnikDTO.getEmail()+" ne postoji!");
        }
        Oglas oglas = modelMapper.map(oglasDTO, Oglas.class);
        oglas.setKorisnik(korisnik);
        oglas.setPodkategorija(podkategorija);
        oglas.setStanjeOglasa(OglasState.NEODOBREN);
        oglas.setPrimio(null);
        Oglas saved = service.createOglas(oglas);
        return ResponseEntity.created(URI.create("/oglas/" + saved.getId())).body(saved);
    }


    @GetMapping(value = "/moji-oglasi")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public List<Oglas> getMojiOglasi(HttpServletRequest req) {
        Korisnik korisnik = korisnikService.whoami(req);
        List<Oglas> oglasi = service.findByEmail(korisnik.getEmail());
        return oglasi;
    }
    @PostMapping(value = "/promjeniStanje/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public Oglas promjeniStanje(@PathVariable("id") long id, @RequestBody String stanje) {
        Oglas oglas = service.getById(id).get();
        oglas.setStanjeOglasa(OglasState.valueOf(stanje));
        return service.createOglas(oglas);
    }
    @DeleteMapping(value = "/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization (value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public  ResponseEntity<Oglas> deleteOglas(@PathVariable("id") long id, HttpServletRequest req) {
        Korisnik korisnik = korisnikService.whoami(req);
        Optional<Oglas> oglasOpt = service.getById(id);
        if(!oglasOpt.isPresent()){
            return ResponseEntity.notFound().build();
        }
        Oglas oglas = oglasOpt.get();
        if (korisnik.getRoles().contains((AppUserRole.ROLE_ADMIN)) || oglas.getKorisnik().getEmail().equals(korisnik.getEmail()) || oglas.getPrimio().equals(korisnik.getEmail())){
            return ResponseEntity.status(HttpStatus.OK).body(service.deleteOglas(id));
        }
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
    }
    @PostMapping(value = "zatvori/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization (value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public  ResponseEntity<String> zatvoriOglas(@PathVariable("id") long id, HttpServletRequest req, @RequestBody String prima) {
        Korisnik korisnik = korisnikService.whoami(req);
        Optional<Oglas> oglasOpt = service.getById(id);
        if(!oglasOpt.isPresent()){
            return ResponseEntity.notFound().build();
        }
        Oglas oglas = oglasOpt.get();
        if(korisnik.getRoles().contains((AppUserRole.ROLE_ADMIN)) || oglas.getKorisnik().getEmail().equals(korisnik.getEmail())){
            oglas.setStanjeOglasa(OglasState.NEAKTIVAN);
            oglas.setPrimio(prima);
            oglas.setVrijemeZatvaranja(Timestamp.valueOf(LocalDateTime.now()));
            service.saveOglas(oglas);
            return ResponseEntity.status(HttpStatus.OK).body("Oglas je zatvoren");
        }
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Nemate pravo da zatvorite ovaj oglas");
    }

    @PostMapping(value = "dorada/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization (value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public  ResponseEntity<String> doradaOglasa(@PathVariable("id") long id, HttpServletRequest req) {
        Korisnik korisnik = korisnikService.whoami(req);
        Optional<Oglas> oglasOpt = service.getById(id);
        if(!oglasOpt.isPresent()){
            return ResponseEntity.notFound().build();
        }
        Oglas oglas = oglasOpt.get();
        if(korisnik.getRoles().contains((AppUserRole.ROLE_ADMIN))){
            oglas.setStanjeOglasa(OglasState.ODBIJEN);
            service.saveOglas(oglas);
            return ResponseEntity.status(HttpStatus.OK).body("Oglas je poslat na doradu");
        }
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Nemate pravo da posaljete ovaj oglas na doradu");
    }

    @PostMapping(value = "/{id}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization (value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public  ResponseEntity<Oglas> ponovoPosalji(@PathVariable("id") long id, @RequestBody OglasDTO oglasDTO, HttpServletRequest req) throws NotFoundException {
        PodkategorijaDTO podkategorijaDTO = oglasDTO.getPodkategorija();
        Podkategorija podkategorija = podkategorijaService.getByNaziv(podkategorijaDTO.getNaziv());
        if(podkategorija == null){
            podkategorija = modelMapper.map(podkategorijaDTO, Podkategorija.class);
            KategorijaDTO kategorijaDTO = podkategorijaDTO.getKategorija();
            Kategorija kategorija = kategorijaService.getByNaziv(kategorijaDTO.getNaziv());
            if(kategorija == null){
                kategorija = modelMapper.map(kategorijaDTO, Kategorija.class);
                kategorijaService.saveKategorija(kategorija);
            }
            podkategorija.setKategorija(kategorija);
            podkategorijaService.savePodKategorija(podkategorija);
        }
        KorisnikDTO korisnikDTO = oglasDTO.getKorisnik();
        Korisnik korisnik = korisnikService.findByEmail(korisnikDTO.getEmail());
        if(korisnik == null){
            throw new NotFoundException("Korisnik sa email-om: " + korisnikDTO.getEmail()+" ne postoji!");
        }
        Oglas oglas = modelMapper.map(oglasDTO, Oglas.class);
        oglas.setKorisnik(korisnik);
        oglas.setPodkategorija(podkategorija);
        oglas.setStanjeOglasa(OglasState.NEODOBREN);
        oglas.setId(id);
        Oglas saved = service.createOglas(oglas);
        return ResponseEntity.created(URI.create("/oglas/" + saved.getId())).body(saved);
        //return ResponseEntity.status(HttpStatus.FORBIDDEN).body(oglas);
    }

    @GetMapping(value = "/listaCekanja")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public List<Oglas> getWaitingOglasi() {
        List<Oglas> oglasi = service.findAll();
        List<Oglas> oglasiCekanja = new ArrayList<>();
        for(Oglas oglas : oglasi){
            if(oglas.getStanjeOglasa() == OglasState.NEODOBREN){
                oglasiCekanja.add(oglas);
            }
        }
        return oglasiCekanja;
    }
    @GetMapping(value = "/preferirani/oglasi")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public ResponseEntity<List<Oglas>> getPreferiraniOglasi( HttpServletRequest req) {
        List<Oglas> oglasi = service.findAll();
        Korisnik korisnik = korisnikService.whoami(req);

        List<String> preference = korisnik.getInteresi();

        if(preference == null){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
        }

        List<Oglas> output = new LinkedList<>();

        for(Oglas oglas: oglasi){
            for(String preferenca: preference){
                if(preferenca.equalsIgnoreCase( oglas.getPodkategorija().getNaziv() )){
                    output.add( oglas );
                }
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(output);
    }
}


