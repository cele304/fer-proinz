package opp.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import lombok.RequiredArgsConstructor;
import opp.dto.UserResponseDTO;
import opp.model.Kategorija;
import opp.model.Oglas;
import opp.model.Podkategorija;
import opp.service.KategorijaService;
import opp.service.PodKategorijaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/util")
@RequiredArgsConstructor
public class UtilController {

    @Autowired
    KategorijaService kategorijaService;

        @GetMapping(value = "/kategorije")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public List<Kategorija> getOglas() {
            return kategorijaService.findAll();
    }
    @GetMapping(value = "/podkategorije/{name}")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_NEPOTVRDENI_KORISNIK') or hasRole('ROLE_POTVRDENI_KORISNIK')")
    @ApiOperation(value = "${UserController.me}", response = UserResponseDTO.class, authorizations = { @Authorization(value="apiKey") })
    @ApiResponses(value = {//
            @ApiResponse(code = 400, message = "Something went wrong"), //
            @ApiResponse(code = 403, message = "Access denied"), //
            @ApiResponse(code = 500, message = "Expired or invalid JWT token")})
    public List<Podkategorija> getOglas(@PathVariable("name") String name) {
            List<Kategorija> kategorije = kategorijaService.findAll();
            for(Kategorija kategorija : kategorije){
                if(kategorija.getNaziv().equals(name)){
                    return kategorija.getPodkategorije();
                }
            }
            return null;
    }

}
