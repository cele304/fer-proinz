package opp;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;
import java.util.stream.Collectors;

import opp.model.*;
import opp.service.AdresaService;
import opp.service.KategorijaService;
import opp.service.KorisnikService;
import opp.service.OglasService;
import opp.service.PodKategorijaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Example component used to insert some test students at application startup.
 */
@Component
public class DataInitializer {
    @Autowired
    private OglasService Oglasservice;

    @Autowired
    private KategorijaService kategorijaService;

    @Autowired
    private PodKategorijaService podkategorijaService;

    @Autowired
    private KorisnikService korisnikService;

    @Autowired
    private AdresaService adresaService;




    @EventListener
    public void appReady(ApplicationReadyEvent event) throws IOException {


        generateKategorija();
        generateKorisnik();
        generateAdmin();
        generateOglasi();
    }

    private void generateOglasi() throws IOException {
        if(!Oglasservice.findAll().isEmpty()){
            return;
        }
        String pathToPictures = "src/main/resources/slike/";

        String naslov = "Doniram lego star wars set";
        String opis = "Radi se Imperial TIE Fighter 75300 setu, originalna kutija i upute uključene.";
        byte[] picInBytes = getPicture(pathToPictures + "lego-tie-fighter.jpeg");
        Calendar datumObjave = Calendar.getInstance();
        datumObjave.set(2022, 11,13);
        Timestamp timestamp = new Timestamp(datumObjave.getTimeInMillis());
        StanjePredmeta stanje = StanjePredmeta.MALO_KORIŠTENO;
        String predvidenaDob = "7";
        Spol predivdenSpol = Spol.UNISEX;
        Calendar rokUpotrebe = null;
        Podkategorija podkategorija = podkategorijaService.getByNaziv("Lego kocke");
        Korisnik korisnik = korisnikService.findByEmail("mario.markovic@gmail.com");
        Oglas oglas = new Oglas(naslov, opis, picInBytes, timestamp, stanje, predvidenaDob, predivdenSpol, rokUpotrebe,podkategorija, korisnik);
        oglas.setPrimio(null);
        oglas.setStanjeOglasa(OglasState.AKTIVAN);
        Oglasservice.saveOglas( oglas );


        naslov = "3 u 1 kolica srednje veličine";
        opis = "Kolica su vrlo praktična i izvrsnog omjera cijene i kvalitete. crna .";
        picInBytes = getPicture(pathToPictures + "3u1-kolica.jpg");
        datumObjave = Calendar.getInstance();
        datumObjave.set(2022, 6,23);
        timestamp = new Timestamp(datumObjave.getTimeInMillis());
        stanje = StanjePredmeta.JAKO_KORIŠTENO;
        predvidenaDob = "1";
        predivdenSpol = Spol.UNISEX;
        rokUpotrebe = null;
        podkategorija = podkategorijaService.getByNaziv("3 u 1");
        korisnik = null;

        oglas = new Oglas(naslov, opis, picInBytes, timestamp, stanje, predvidenaDob, predivdenSpol, rokUpotrebe,podkategorija, korisnik);
        oglas.setStanjeOglasa(OglasState.NEAKTIVAN);
        oglas.setPrimio(null);
        Oglasservice.saveOglas( oglas );


        naslov = "Plišana igračka pikachu";
        opis = "Doniran plišanu igračku pikachu, moj sin ju je prerastao i više nemamo potrebe za njom. Veličina igračke je 20 cm.";
        picInBytes = getPicture(pathToPictures + "pikachu.jpg");
        datumObjave = Calendar.getInstance();
        datumObjave.set(2022, 10,6);
        timestamp = new Timestamp(datumObjave.getTimeInMillis());
        stanje = StanjePredmeta.SREDNJE_KORIŠTENO;
        predvidenaDob = "1";
        predivdenSpol = Spol.UNISEX;
        rokUpotrebe = null;
        podkategorija = podkategorijaService.getByNaziv("Plišane igračke");
        korisnik = korisnikService.findByEmail("mario.markovic@gmail.com");

        oglas = new Oglas(naslov, opis, picInBytes, timestamp, stanje, predvidenaDob, predivdenSpol, rokUpotrebe,podkategorija, korisnik);
        oglas.setStanjeOglasa(OglasState.NEODOBREN);
        oglas.setPrimio(null);
        Oglasservice.saveOglas( oglas );

        naslov = "Majca za djevojčice";
        opis = "majca za djevojčice veličine 104";
        picInBytes = getPicture(pathToPictures + "majca.jpg");
        datumObjave = Calendar.getInstance();
        datumObjave.set(2022, 11,11);
        timestamp = new Timestamp(datumObjave.getTimeInMillis());
        stanje = StanjePredmeta.NOVO;
        predvidenaDob = "3";
        predivdenSpol = Spol.Ž;
        rokUpotrebe = null;
        podkategorija = podkategorijaService.getByNaziv("Majce");
        korisnik = null;

        oglas = new Oglas(naslov, opis, picInBytes, timestamp, stanje, predvidenaDob, predivdenSpol, rokUpotrebe,podkategorija, korisnik);
        oglas.setStanjeOglasa(OglasState.NEODOBREN);
        oglas.setPrimio(null);
        Oglasservice.saveOglas( oglas );

    }

    private void generateKategorija() {
        if(!kategorijaService.findAll().isEmpty()){
            return;
        }
        // Igračke
        Kategorija kategorija = new Kategorija();
        kategorija.setNaziv( "Igračke" );
        kategorijaService.saveKategorija( kategorija );

        Podkategorija podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Lego kocke" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

         podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Plišane igračke" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

         podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Lutke" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        kategorija = new Kategorija();
        kategorija.setNaziv( "Kolica" );
        kategorijaService.saveKategorija( kategorija );

         podkategorija = new Podkategorija();
        podkategorija.setNaziv( "3 u 1" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Kišobran kolica" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Dodaci za kolica" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        kategorija = new Kategorija();
        kategorija.setNaziv( "Namještaj" );
        kategorijaService.saveKategorija( kategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Kreveti" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Hranilice" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Komode za prematenje" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        kategorija = new Kategorija();
        kategorija.setNaziv( "Odjeća" );
        kategorijaService.saveKategorija( kategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Majce" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Hlače" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        podkategorija = new Podkategorija();
        podkategorija.setNaziv( "Cipele" );
        podkategorija.setKategorija( kategorija );
        podkategorijaService.savePodKategorija( podkategorija );

        kategorija = new Kategorija();
        kategorija.setNaziv( "Razno" );
        kategorijaService.saveKategorija( kategorija );

    }

    private Korisnik generateKorisnik() {
        String email = "mario.markovic@gmail.com";
        Korisnik k = null;
        try {
            k = korisnikService.findAll().stream().filter(korisnik -> korisnik.getEmail().equals(email)).findFirst().get();
        }catch (Exception e){

        }
        if(k != null){
            return k;
        }
        Korisnik korisnik = new Korisnik();
        korisnik.setIme( "Mario" );
        korisnik.setPrezime( "Markovic" );
        korisnik.setEmail( email );
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode("123456");
        korisnik.setLozinka(encodedPassword);
        korisnik.setAdresa( generateAdresa() );
        korisnik.setBrojMobitela( "0987654321" );
        korisnik.getAdresa().setKorisnici( korisnik );
        korisnik.setRoles(new ArrayList<AppUserRole>(Arrays.asList(AppUserRole.ROLE_NEPOTVRDENI_KORISNIK)));

        List<String> interesi = this.podkategorijaService.findAll().stream().map( s -> s.getNaziv() ).collect( Collectors.toList());

        korisnik.setInteresi(interesi);

        korisnikService.saveKorisnik( korisnik );
        return korisnik;
    }

    private Korisnik generateAdmin() {
        String email = "admin";
        Korisnik k = null;
        try {
             k = korisnikService.findAll().stream().filter(korisnik -> korisnik.getEmail().equals(email)).findFirst().get();
        }catch (Exception e){

        }
        if(k != null){
            return k;
        }
        Korisnik korisnik = new Korisnik();
        korisnik.setIme( "Admin" );
        korisnik.setPrezime( "Admin" );
        korisnik.setEmail( email );
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode("admin");
        korisnik.setLozinka(encodedPassword);
        korisnik.setBrojMobitela( "000000000" );
        korisnik.setRoles(new ArrayList<AppUserRole>(Arrays.asList(AppUserRole.ROLE_ADMIN)));
        korisnik.setInteresi(List.of("Hlače", "3 u 1"));
        korisnikService.saveKorisnik( korisnik );
        return korisnik;
    }

    private Adresa generateAdresa() {
        Adresa adresa = new Adresa();
        adresa.setGrad( "Zagreb" );
        adresa.setUlica( "Trg bana Josipa Jelacica" );
        adresa.setZipcode( "10000" );
        return adresa;
    }

    private byte[] getPicture(String path) throws IOException {
        File file = new File(path);
        byte[] picInBytes = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(picInBytes);
        fileInputStream.close();
        return picInBytes;
    }


}
