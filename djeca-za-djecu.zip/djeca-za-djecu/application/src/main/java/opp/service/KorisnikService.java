package opp.service;

import lombok.RequiredArgsConstructor;
import opp.exception.CustomException;
import opp.model.AppUserRole;
import opp.model.Korisnik;
import opp.repository.KorisnikRepository;
import opp.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@RequiredArgsConstructor
public class KorisnikService {
    @Autowired
    private KorisnikRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;
    private final AuthenticationManager authenticationManager;


    public Korisnik getById(long id) {
        return repository.getById( id );
    }

    public List<Korisnik> findAll() {
        return repository.findAll();
    }

    public Korisnik saveKorisnik(Korisnik korisnik) {
        return repository.save( korisnik );
    }


    public Korisnik registerUser(Korisnik korisnik) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode( korisnik.getLozinka() );
        korisnik.setLozinka( encodedPassword );
        //        korisnik.setRoles(Arrays.asList((roleRepository.findByName("ROLE_USER"))));
        korisnik.setLozinka( encodedPassword );
        return repository.save( korisnik );
    }

    public String signin(String username, String password) {
        try {
            authenticationManager.authenticate( new UsernamePasswordAuthenticationToken( username, password ) );
            return jwtTokenProvider.createToken( username, repository.findByEmail( username ).getRoles() );
        } catch (AuthenticationException e) {
            throw new CustomException( "Invalid username/password supplied", HttpStatus.UNPROCESSABLE_ENTITY );
        }
    }

    public String signup(Korisnik appUser) {
        if (!repository.existsByEmail( appUser.getEmail() )) {
            appUser.setLozinka( passwordEncoder.encode( appUser.getLozinka() ) );
            //Obican user na pocetku
            appUser.setRoles(new ArrayList<AppUserRole>( Arrays.asList(AppUserRole.ROLE_NEPOTVRDENI_KORISNIK)));            repository.save( appUser );
            return jwtTokenProvider.createToken( appUser.getEmail(), appUser.getRoles() );
        } else {
            throw new CustomException( "Username is already in use", HttpStatus.UNPROCESSABLE_ENTITY );
        }
    }

    public void delete(String username) {
        repository.deleteByEmail( username );
    }

    public Korisnik search(String username) {
        Korisnik appUser = repository.findByEmail( username );
        if (appUser == null) {
            throw new CustomException( "The user doesn't exist", HttpStatus.NOT_FOUND );
        }
        return appUser;
    }

    public Korisnik whoami(HttpServletRequest req) {
        return repository.findByEmail( jwtTokenProvider.getUsername( jwtTokenProvider.resolveToken( req ) ) );
    }

    public Korisnik whoami(String token) {
        return repository.findByEmail( jwtTokenProvider.getUsername( token ) );
    }

    public String refresh(String username) {
        return jwtTokenProvider.createToken( username, repository.findByEmail( username ).getRoles() );
    }


    public Korisnik findByEmail(String email) {
        return repository.findByEmail( email );
    }

    public Korisnik findById(Long id) {
        return repository.findById( id ).orElse( null );
    }
}
