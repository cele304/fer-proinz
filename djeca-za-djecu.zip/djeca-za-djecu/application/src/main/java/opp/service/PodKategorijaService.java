package opp.service;

import opp.model.Podkategorija;
import opp.repository.PodKategorijaRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PodKategorijaService {

    @Autowired
    private PodKategorijaRepository repository;

    public Optional<Podkategorija> getById(long id) {
        return repository.findById(id);
      }


    public Podkategorija savePodKategorija(Podkategorija podkategorija) {
        return repository.save(podkategorija);
      }


  public Podkategorija getByNaziv(String naziv){
        return repository.getPodkategorijaByName(naziv);
  }

  public List<Podkategorija> findAll(){
        return  repository.findAll();
  }


}
