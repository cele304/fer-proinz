package opp.service;

import opp.model.Dijete;
import opp.repository.DijeteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DijeteService {

	@Autowired
	DijeteRepository repository;

	public Dijete saveDijete(Dijete dijete){
		return this.repository.save( dijete );
	}

}
