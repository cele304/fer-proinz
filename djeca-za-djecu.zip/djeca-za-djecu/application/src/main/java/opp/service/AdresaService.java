package opp.service;

import opp.model.Adresa;
import opp.repository.AdresaRepository;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdresaService {

	@Autowired
	AdresaRepository repository;

	public Optional<Adresa> getById(long id) {
		return repository.findById(id);
	}

	public List<Adresa> findAll() {
		return repository.findAll();
	}

	public Adresa saveAdresa(Adresa adresa) {
		return repository.save(adresa);
	}
}
