package opp.service;

import opp.model.Kategorija;
import opp.repository.KategorijaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KategorijaService {

    @Autowired
    private KategorijaRepository repository;

    public Kategorija saveKategorija(Kategorija kategorija) {
        return repository.save(kategorija);
      }


    public Kategorija getByNaziv(String naziv){
        return repository.getKategorijaByName(naziv);
    }

    public List<Kategorija> findAll() {
        return repository.findAll();

    }
}
