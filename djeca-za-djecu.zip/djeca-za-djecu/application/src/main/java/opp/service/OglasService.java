package opp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import opp.model.Oglas;
import opp.repository.OglasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OglasService {

    @Autowired
    private OglasRepository repository;

    public Optional<Oglas> getById(long id) {
        return repository.findById(id);
      }

      public List<Oglas> findAll() {
          return repository.findAll();
        }

    public Oglas saveOglas(Oglas oglas) {
        return repository.save(oglas);
      }


    public Oglas createOglas(Oglas oglas) {
        return repository.save(oglas);
      }

    public List<Oglas> findByEmail(String email) {
        List<Oglas> oglasi = repository.findAll();
        List<Oglas> oglasiKorisnika = new ArrayList<>();
        for (Oglas oglas : oglasi) {

            if (oglas.getKorisnik() != null && oglas.getKorisnik().getEmail().equals(email)) {
                oglasiKorisnika.add(oglas);
            }
        }
        return oglasiKorisnika;
      }

    public Oglas deleteOglas(long id) {
        Oglas oglas = repository.findById(id).get();
        repository.delete(oglas);
        return oglas;

    }
}
