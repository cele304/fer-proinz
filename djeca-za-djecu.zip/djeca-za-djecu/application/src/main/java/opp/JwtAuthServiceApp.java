package opp;

import java.util.ArrayList;
import java.util.Arrays;

import lombok.RequiredArgsConstructor;
import opp.model.AppUserRole;
import opp.model.Korisnik;
import opp.service.KorisnikService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
@RequiredArgsConstructor
public class JwtAuthServiceApp implements CommandLineRunner {

	@Autowired
  final KorisnikService userService;

  public static void main(String[] args) {
    SpringApplication.run(JwtAuthServiceApp.class, args);
  }

  @Bean
  public ModelMapper modelMapper() {
    return new ModelMapper();
  }

  @Override
  public void run(String... params) throws Exception {
//    Korisnik admin = new Korisnik();
//    admin.setIme("admin");
//    admin.setLozinka("admin");
//    admin.setEmail("admin@email.com");
//    admin.setRoles(new ArrayList<AppUserRole>(Arrays.asList(AppUserRole.ROLE_ADMIN)));
//
//    userService.signup(admin);

  }

}
