package opp.repository;

import opp.model.Kategorija;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface KategorijaRepository  extends JpaRepository<Kategorija, Long> {
    @Query("SELECT k FROM Kategorija k WHERE k.naziv = ?1")
    public Kategorija getKategorijaByName(String naziv);
}
