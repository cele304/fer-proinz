package opp.repository;

import opp.model.Oglas;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OglasRepository  extends JpaRepository<Oglas, Long>{

}
