package opp.repository;

import opp.model.Adresa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdresaRepository extends JpaRepository<Adresa, Long>{

}
