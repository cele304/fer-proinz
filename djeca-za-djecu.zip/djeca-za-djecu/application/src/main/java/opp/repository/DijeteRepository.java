package opp.repository;

import opp.model.Dijete;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DijeteRepository extends JpaRepository<Dijete, Long> {

}
