package opp.repository;

import opp.model.Korisnik;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface KorisnikRepository extends JpaRepository<Korisnik, Long>{

    @Query("SELECT k FROM Korisnik k WHERE k.email = ?1")
    public Korisnik findByEmail(String email);

    boolean existsByEmail(String email);


    @Transactional
    void deleteByEmail(String email);
}
