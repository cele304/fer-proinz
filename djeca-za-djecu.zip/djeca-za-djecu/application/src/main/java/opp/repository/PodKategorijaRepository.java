package opp.repository;

import opp.model.Podkategorija;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;

public interface PodKategorijaRepository  extends JpaRepository<Podkategorija, Long> {
    @Query("SELECT k FROM Podkategorija k WHERE k.naziv = ?1")
    public Podkategorija getPodkategorijaByName(String naziv);
}
