package opp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

@Entity()
@Table(name = "Oglas")
public class Oglas {
	@Id
	@GeneratedValue
	private long id;

	@Column(nullable = false, length = 64)
	private String naslov;

	@Column(length = 200)
	private String opis;
	@Lob
	private byte[] slika;

	@Column(nullable = false, length = 40)
	private Timestamp datumObjave;
	@Enumerated(EnumType.STRING)
	@Column(nullable = false, length = 30)
	private StanjePredmeta stanjePredmeta;
	private String predvidenaDob;
	@Enumerated(EnumType.STRING)
	private Spol predivdenSpol;

	@Temporal(TemporalType.DATE)
	private Calendar rokUpotrebe;

	private OglasState stanjeOglasa;

	@ManyToOne
	@JsonBackReference
	private Podkategorija podkategorija;

	@ManyToOne
	@JsonManagedReference
	private Korisnik korisnik;

	@Column()
	private String primio;

	@Column()
	private Timestamp vrijemeZatvaranja;
	public Oglas(String naslov, String opis, byte[] slika, Timestamp datumObjave, StanjePredmeta stanjePredmeta,
				 String predvidenaDob, Spol predivdenSpol, Calendar rokUpotrebe, Podkategorija podkategorija, Korisnik korisnik) {
		this.naslov = naslov;
		this.opis = opis;
		this.slika = slika;
		this.datumObjave = datumObjave;
		this.stanjePredmeta = stanjePredmeta;
		this.predvidenaDob = predvidenaDob;
		this.predivdenSpol = predivdenSpol;
		this.rokUpotrebe = rokUpotrebe;
		this.podkategorija = podkategorija;
		this.korisnik = korisnik;
	}

	public Oglas() {
		super();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNaslov() {
		return naslov;
	}

	public void setNaslov(String naslov) {
		this.naslov = naslov;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public byte[] getSlika() {
		return slika;
	}

	public void setSlika(byte[] slika) {
		this.slika = slika;
	}

	public Timestamp getDatumObjave() {
		return datumObjave;
	}

	public void setDatumObjave(Timestamp datumObjave) {
		this.datumObjave = datumObjave;
	}

	public StanjePredmeta getStanjePredmeta() {
		return stanjePredmeta;
	}

	public void setStanjePredmeta(StanjePredmeta stanjePredmeta) {
		this.stanjePredmeta = stanjePredmeta;
	}

	public String getPredvidenaDob() {
		return predvidenaDob;
	}

	public void setPredvidenaDob(String predvidenaDob) {
		this.predvidenaDob = predvidenaDob;
	}

	public Spol getPredivdenSpol() {
		return predivdenSpol;
	}

	public void setPredivdenSpol(Spol predivdenSpol) {
		this.predivdenSpol = predivdenSpol;
	}

	public Calendar getRokUpotrebe() {
		return rokUpotrebe;
	}

	public void setRokUpotrebe(Calendar rokUpotrebe) {
		this.rokUpotrebe = rokUpotrebe;
	}

	public Podkategorija getPodkategorija() {
		return podkategorija;
	}

	public void setPodkategorija(Podkategorija podkategorija) {
		this.podkategorija = podkategorija;
	}

	public Korisnik getKorisnik() {
		return korisnik;
	}

	public void setKorisnik(Korisnik korisnik) {
		this.korisnik = korisnik;
	}

	public OglasState getStanjeOglasa() {
		return stanjeOglasa;
	}

	public void setStanjeOglasa(OglasState stanjeOglasa) {
		this.stanjeOglasa = stanjeOglasa;
	}

	public String getPrimio() {
		return primio;
	}

	public void setPrimio(String primio) {
		this.primio = primio;
	}

	public Timestamp getVrijemeZatvaranja() {
		return vrijemeZatvaranja;
	}

	public void setVrijemeZatvaranja(Timestamp vrijemeZatvaranja) {
		this.vrijemeZatvaranja = vrijemeZatvaranja;
	}
}
