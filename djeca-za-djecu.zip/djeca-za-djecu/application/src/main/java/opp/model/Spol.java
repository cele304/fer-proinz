package opp.model;

public enum Spol {
    M, Ž, UNISEX
}
