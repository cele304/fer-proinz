package opp.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.*;

@Entity(name = "Kategorija")
@Table(name = "kategorija")
public class Kategorija {

	@Id
	@GeneratedValue
	private long id;

	@Column(nullable = false, length = 50)
	private String naziv;
	@JsonManagedReference
	@OneToMany(mappedBy = "kategorija", cascade = CascadeType.ALL)
	private List<Podkategorija> podkategorije;

	public Kategorija(String naziv, List<Podkategorija> podKategorije) {
		this.naziv = naziv;
		this.podkategorije = podKategorije;
	}

	public Kategorija() {
		super();
		podkategorije = new LinkedList<Podkategorija>();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public List<Podkategorija> getPodkategorije() {
		return podkategorije;
	}

	public void setPodkategorije(List<Podkategorija> podkategorije) {
		this.podkategorije = podkategorije;
	}
}
