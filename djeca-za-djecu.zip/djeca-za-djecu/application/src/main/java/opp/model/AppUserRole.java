package opp.model;

import org.springframework.security.core.GrantedAuthority;

public enum AppUserRole implements GrantedAuthority {
  ROLE_ADMIN, ROLE_NEPOTVRDENI_KORISNIK, ROLE_POTVRDENI_KORISNIK, ;

  public String getAuthority() {
    return name();
  }

}
