package opp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.NoArgsConstructor;
import opp.dto.KorisnikDTO;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

import javax.persistence.*;

import static org.springframework.security.core.authority.AuthorityUtils.commaSeparatedStringToAuthorityList;

@Entity()
@Table(name = "Korisnik")
@Data // Create getters and setters
@NoArgsConstructor
public class Korisnik {

    @Id
    @GeneratedValue
    private long id;

    @Column(nullable = false, unique = true, length = 45)
    private String email;

    @Column(nullable = false, length = 128)
    private String lozinka;

    @Column(nullable = false, length = 20)
    private String ime;

    @Column(nullable = false, length = 20)
    private String prezime;

    @Column(length = 20)
    private String brojMobitela;


    @ManyToOne(cascade = CascadeType.PERSIST)
    @JsonManagedReference
    private Adresa adresa;

    @JsonManagedReference
    @OneToMany(mappedBy = "korisnik")
    private List<Dijete> dijete = new LinkedList<>();

    @JsonBackReference
    @OneToMany(mappedBy = "korisnik")
    private List<Oglas> oglasi = new LinkedList<>();

    @ElementCollection(fetch = FetchType.EAGER)
    private List<AppUserRole> roles = new LinkedList<>();;

    @ElementCollection(fetch = FetchType.LAZY)
    private List<String> interesi = new LinkedList<>();

    private Boolean locked = false;
    private Boolean enabled = false;


    public Korisnik(String email, String lozinka, String ime, String prezime, String brojMobitela,
                    Adresa adresa, List<Dijete> djeca, List<Oglas> oglasi) {
        this.email = email;
        this.lozinka = lozinka;
        this.ime = ime;
        this.prezime = prezime;
        this.brojMobitela = brojMobitela;
        this.adresa = adresa;
        this.dijete = djeca;
        this.oglasi = oglasi;
    }
    public Korisnik(KorisnikDTO korisnikDTO){
        this.email = korisnikDTO.getEmail();
        this.lozinka = korisnikDTO.getLozinka();
        this.ime = korisnikDTO.getIme();
        this.prezime = korisnikDTO.getPrezime();
        this.brojMobitela = korisnikDTO.getBrojMobitela();
        this.dijete = new LinkedList<>();
        this.oglasi = new LinkedList<>();
        this.adresa = new Adresa(korisnikDTO.getAdresa());

        for(Dijete tmp: dijete){
            tmp.setKorisnik(this);
        }

        adresa.setKorisnici(this);

    }

}
