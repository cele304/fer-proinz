package opp.model;

public enum OglasState {
    ODBIJEN, NEODOBREN, AKTIVAN, NEAKTIVAN
}
