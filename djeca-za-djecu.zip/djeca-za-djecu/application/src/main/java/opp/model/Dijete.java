package opp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity()
@Table(name = "dijete")
public class Dijete {

    @Id
    @GeneratedValue
    private long id;

    @Column(nullable=false)
    @Size(min=1, max=1)
    private String spol;

    @Temporal(TemporalType.DATE)
    private Date datumRodjenja;

    @ManyToOne
    @JsonBackReference
    private Korisnik korisnik;

    public Dijete() {
    }

    public Dijete(String spol, Date datumRodjenja, Korisnik korisnik) {
        this.spol = spol;
        this.datumRodjenja = datumRodjenja;
        this.korisnik = korisnik;

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSpol() {
        return spol;
    }

    public void setSpol(String spol) {
        this.spol = spol;
    }

    public Date getDatumRodjenja() {
        return datumRodjenja;
    }

    public void setDatumRodjenja(Date datumRodjenja) {
        this.datumRodjenja = datumRodjenja;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }
}
