package opp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity()
@Table(name = "Podkategorija")
public class Podkategorija {
	@Id
	@GeneratedValue
	private long id;

	@Column(nullable = false, length = 50)
	private String naziv;

	@ManyToOne
	@JsonBackReference
	private Kategorija kategorija;

	@JsonManagedReference
	@OneToMany(mappedBy = "podkategorija")
	private List<Oglas> oglasi;

	public Podkategorija() {
		super();
		oglasi = new ArrayList<>();
	}

	public Podkategorija(String naziv, Kategorija kategorija, List<Oglas> oglasi) {
		this.naziv = naziv;
		this.kategorija = kategorija;
		this.oglasi = oglasi;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public Kategorija getKategorija() {
		return kategorija;
	}

	public void setKategorija(Kategorija kategorija) {
		this.kategorija = kategorija;
	}

	public List<Oglas> getOglasi() {
		return oglasi;
	}

	public void setOglasi(List<Oglas> oglasi) {
		this.oglasi = oglasi;
	}
}

