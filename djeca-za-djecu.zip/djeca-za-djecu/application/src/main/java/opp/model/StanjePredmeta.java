package opp.model;

public enum StanjePredmeta {
    NOVO, MALO_KORIŠTENO, JAKO_KORIŠTENO, SREDNJE_KORIŠTENO
}
