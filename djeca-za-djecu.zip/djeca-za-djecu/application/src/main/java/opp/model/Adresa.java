package opp.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import opp.dto.AdresaDTO;

import javax.persistence.*;

@Entity()
@Table(name = "Adresa")
public class Adresa {

	@Id
	@GeneratedValue
	private long id;

	@Column(length = 30)
	String grad;

	@Column(length = 40)
	String ulica;

	@Column(length = 20)
	String zipcode;

	@JsonBackReference
	@OneToOne()
	private Korisnik korisnici;

	public Adresa(String ulica,String grad, String zipcode, Korisnik korisnici) {
		this.ulica = ulica;
		this.grad = grad;
		this.zipcode = zipcode;
		this.korisnici = korisnici;
	}

	public Adresa(AdresaDTO adresaDTO){
		this.ulica = adresaDTO.getUlica();
		this.grad = adresaDTO.getGrad();
		this.zipcode = adresaDTO.getZipcode();
	}


	public Adresa() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUlica() {
		return ulica;
	}

	public void setUlica(String ulica) {
		this.ulica = ulica;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}


	public Korisnik getKorisnici() {
		return korisnici;
	}

	public void setKorisnici(Korisnik korisnici) {
		this.korisnici = korisnici;
	}

	public String getGrad() {
		return grad;
	}

	public void setGrad(String grad) {
		this.grad = grad;
	}
}

