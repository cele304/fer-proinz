package opp.dto;

public class KategorijaDTO {

    private String naziv;


    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }
}


