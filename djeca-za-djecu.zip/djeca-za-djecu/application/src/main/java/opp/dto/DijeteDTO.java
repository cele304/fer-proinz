package opp.dto;

import opp.model.Dijete;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class DijeteDTO {

    private String spol;

    private Date datumRodjenja;

    private KorisnikDTO korisnik;

    public String getSpol() {
        return spol;
    }

    public void setSpol(String spol) {
        this.spol = spol;
    }

    public Date getDatumRodjenja() {
        return datumRodjenja;
    }

    public void setDatumRodjenja(Date datumRodjenja) {
        this.datumRodjenja = datumRodjenja;
    }

    public KorisnikDTO getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(KorisnikDTO korisnik) {
        this.korisnik = korisnik;
    }

    public static List<DijeteDTO> of(List<Dijete> djeca) {
        List<DijeteDTO> output = new LinkedList<>();

        for(Dijete tmp : djeca){
            DijeteDTO dijete = new DijeteDTO();
            dijete.setSpol( tmp.getSpol() );
            dijete.setDatumRodjenja( tmp.getDatumRodjenja() );
            output.add( dijete );
        }

        return  output;
    }
}
