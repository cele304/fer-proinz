package opp.dto;

public class PodkategorijaDTO {

    private String naziv;

    private KategorijaDTO kategorija;

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public KategorijaDTO getKategorija() {
        return kategorija;
    }

    public void setKategorija(KategorijaDTO kategorija) {
        this.kategorija = kategorija;
    }
}
