package opp.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import opp.model.AppUserRole;

@Data
@NoArgsConstructor
public class UserDataDTO {

  @ApiModelProperty(position = 0)
  private String ime;


  @ApiModelProperty(position = 1)
  private String email;


  @ApiModelProperty(position = 2)
  private String lozinka;


  @ApiModelProperty(position = 3)
  List<AppUserRole> roles;

}
