package opp.dto;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import opp.model.AppUserRole;

@Data
public class UserResponseDTO {

  private Integer id;

  private String email;

  List<AppUserRole> roles;

}
