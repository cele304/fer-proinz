package opp.dto;

import opp.model.Adresa;

public class AdresaDTO {
    private String grad;

    private String ulica;

    private String zipcode;


    public String getGrad() {
        return grad;
    }

    public void setGrad(String grad) {
        this.grad = grad;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public static AdresaDTO of(Adresa adresa) {
        AdresaDTO output = new AdresaDTO();

        if(adresa == null){
            return null;
        }

        output.setGrad( adresa.getGrad() );
        output.setUlica( adresa.getUlica() );
        output.setZipcode( adresa.getZipcode() );

        return output;
    }
}

