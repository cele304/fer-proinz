package opp.dto;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opp.model.AppUserRole;
import opp.model.Korisnik;

import java.util.List;

@Data // Create getters and setters
@NoArgsConstructor
public class KorisnikDTO {

    private String email;

    private String lozinka;

    private String ime;

    private String prezime;

    private String brojMobitela;

    private AdresaDTO adresa;

    private List<DijeteDTO> dijete;

    private List<OglasDTO> oglasi;

    private List<AppUserRole> roles;

	public String getEmail() {
		return email;
	}

    public static KorisnikDTO of(Korisnik tmp) {
        KorisnikDTO output = new KorisnikDTO();

        try{
        output.setIme( tmp.getIme() );
        output.setPrezime( tmp.getPrezime() );
        output.setEmail( tmp.getEmail() );
        output.setBrojMobitela( tmp.getBrojMobitela() );
        output.setDijete( DijeteDTO.of(tmp.getDijete()) );
        output.setAdresa( AdresaDTO.of(tmp.getAdresa()) );
        output.setRoles( tmp.getRoles() );
        output.setOglasi( OglasDTO.of(tmp.getOglasi()) );
        }catch (Exception ignorable){

        }

        return output;
    }
}
