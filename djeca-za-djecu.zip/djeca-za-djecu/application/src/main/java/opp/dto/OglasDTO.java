package opp.dto;

import lombok.Data;
import opp.model.Oglas;
import opp.model.OglasState;
import opp.model.Spol;
import opp.model.StanjePredmeta;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

@Data
public class OglasDTO

{

    private String naslov;
    private String opis;

    private byte[] slika;

    private Timestamp datumObjave;

    private StanjePredmeta stanjePredmeta;
    private String predvidenaDob;

    private Spol predivdenSpol;

    private Calendar rokUpotrebe;

    private OglasState stanjeOglasa;

    private PodkategorijaDTO podkategorija;

    private KorisnikDTO korisnik;

    private String primio;

    private Timestamp vrijemeZatvaranja;

    public String getNaslov() {
        return naslov;
    }

    public void setNaslov(String naslov) {
        this.naslov = naslov;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public byte[] getSlika() {
        return slika;
    }

    public void setSlika(byte[] slika) {
        this.slika = slika;
    }

    public Timestamp getDatumObjave() {
        return datumObjave;
    }

    public void setDatumObjave(Timestamp datumObjave) {
        this.datumObjave = datumObjave;
    }

    public KorisnikDTO getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(KorisnikDTO korisnik) {
        this.korisnik = korisnik;
    }

    public StanjePredmeta getStanjePredmeta() {
        return stanjePredmeta;
    }

    public void setStanjePredmeta(StanjePredmeta stanjePredmeta) {
        this.stanjePredmeta = stanjePredmeta;
    }

    public String getPredvidenaDob() {
        return predvidenaDob;
    }

    public void setPredvidenaDob(String predvidenaDob) {
        this.predvidenaDob = predvidenaDob;
    }

    public Spol getPredivdenSpol() {
        return predivdenSpol;
    }

    public void setPredivdenSpol(Spol predivdenSpol) {
        this.predivdenSpol = predivdenSpol;
    }

    public Calendar getRokUpotrebe() {
        return rokUpotrebe;
    }

    public void setRokUpotrebe(Calendar rokUpotrebe) {
        this.rokUpotrebe = rokUpotrebe;
    }

    public PodkategorijaDTO getPodkategorija() {
        return podkategorija;
    }

    public void setPodkategorija(PodkategorijaDTO podkategorija) {
        this.podkategorija = podkategorija;
    }

    public static List<OglasDTO> of(List<Oglas> oglasi) {
        List<OglasDTO> output = new LinkedList<>();

        if(oglasi == null){
            return  null;
        }

        for(Oglas tmp: oglasi){
            OglasDTO oglas = new OglasDTO();
            oglas.setNaslov( tmp.getNaslov() );
            oglas.setOpis( tmp.getOpis() );
            oglas.setDatumObjave( tmp.getDatumObjave() );
            output.add( oglas );
        }
        return  output;
    }

    public OglasState getStanjeOglasa() {
        return stanjeOglasa;
    }

    public void setStanjeOglasa(OglasState stanjeOglasa) {
        this.stanjeOglasa = stanjeOglasa;
    }

    public String getPrimio() {
        return primio;
    }

    public void setPrimio(String primio) {
        this.primio = primio;
    }

    public Timestamp getVrijemeZatvaranja() {
        return vrijemeZatvaranja;
    }

    public void setVrijemeZatvaranja(Timestamp vrijemeZatvaranja) {
        this.vrijemeZatvaranja = vrijemeZatvaranja;
    }
}
