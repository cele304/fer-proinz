#!/bin/bash
PGPASSWORD=bazepodataka psql -h db -p 5432 -U postgres -c "create database react;" && true

npx serve dist -p 5173