export interface Category {
  id: string;
  naziv: string;
  kategorija: Category | undefined;
}

export interface Listing {
  id: string;
  naslov: string;
  opis: string;
  slika?: string;
  datumObjave: string;
  stanjePredmeta:
    | "NOVO"
    | "MALO_KORIŠTENO"
    | "SREDNJE_KORIŠTENO"
    | "JAKO_KORIŠTENO";
  predvidenaDob: string;
  predivdenSpol: "M" | "Ž" | "UNISEX";
  rokUpotrebe?: string;
  // podkategorija: Category;
  stanjeOglasa?: "ODBIJEN" | "NEODOBREN" | "AKTIVAN" | "NEAKTIVAN";
  korisnik?: User;
  primio: string | null;
  vrijemeZatvaranja: string | null;
}

export interface User {
  ime: string;
  prezime: string;
  email: string;
  roles:
    | ("ROLE_ADMIN" | "ROLE_POTVRDENI_KORISNIK" | "ROLE_NEPOTVRDENI_KORSINIK")[]
    | undefined;
  brojMobitela: string | undefined;
  adresa: {
    zipcode: string | undefined;
    ulica: string | undefined;
    grad: string | undefined;
  } | null;
  dijete:
    | ({
        spol: string | null;
        datumRodjenja: string | null;
      } | null)[]
    | null;
}
