import useSWR, { useSWRConfig } from "swr";
import dayjs from "dayjs";

import { Listing, User } from "@/types/listings";
import { Badge, Card } from "@/ui/cards";
import { Heading, Paragraph } from "@/ui/typography";
import { BorderRadius, Breakpoints, styled } from "@/ui/theme";
import { ErrorMessage, LoadingMessage, Message } from "./messages";
import { Link, Redirect, useLocation, useRoute } from "wouter";
import { Button } from "@/ui/buttons";
import { useMutation } from "@/swr";

const ListingImage = styled("img")`
  object-fit: cover;

  border: 1px solid ${({ theme }) => theme.border};
  border-radius: ${BorderRadius.md}px;

  height: 250px;
  width: 100%;

  @media (min-width: ${Breakpoints.md}px) {
    height: 150px;
    width: 150px;
  }
`;

const sexMessages = {
  M: "za dječake",
  Ž: "za djevojčice",
  UNISEX: "unisex",
};

const conditionMessages = {
  NOVO: "novo",
  MALO_KORIŠTENO: "slabo korišteno",
  SREDNJE_KORIŠTENO: "korišteno",
  JAKO_KORIŠTENO: "rabljeno",
};

const statusMessages = {
  ODBIJEN: "odbijen",
  NEODOBREN: "neodobren",
  AKTIVAN: "aktivan",
  NEAKTIVAN: "neaktivan",
};

const StyledCard = styled(Card)<{ $colored: boolean }>`
  ${({ theme, $colored }) =>
    $colored &&
    `background-color: ${theme.primary[25]};
    border-color: ${theme.primary[100]};
    `}
`;

export const ListingCard = ({
  listing,
  showStatus,
  colored = false,
}: {
  listing: Listing;
  showStatus?: boolean;
  colored?: boolean;
}) => {
  const dateFormatter = new Intl.DateTimeFormat("hr", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  return (
    <StyledCard
      as="article"
      $colored={colored}
      key={listing.id}
      className="d-flex"
    >
      <div className="d-flex flex-column md-flex-row align-items-start g-16 md-g-32">
        {listing.slika && (
          <ListingImage src={`data:image/jpeg;base64,${listing.slika}`} />
        )}

        <div className="flex-1 d-flex flex-column justify-content-between g-8">
          <Heading as="h2" className="text-truncate-2">
            <Link href={`/listings/${listing.id}`}>{listing.naslov}</Link>
          </Heading>

          <div className="d-flex g-8 flex-wrap">
            {showStatus && listing.stanjeOglasa && (
              <Badge colored>
                status: {statusMessages[listing.stanjeOglasa]}
              </Badge>
            )}

            {!!listing.predivdenSpol && (
              <Badge>{sexMessages[listing.predivdenSpol]}</Badge>
            )}

            {!!listing.predvidenaDob && <Badge>{listing.predvidenaDob}</Badge>}

            <Badge>{conditionMessages[listing.stanjePredmeta]}</Badge>
          </div>

          <Paragraph className="text-truncate-2 md-mb-16">
            {listing.opis}
          </Paragraph>
        </div>
      </div>

      <div className="d-flex flex-column mt-16 md-mt-0 align-items-end">
        {listing.rokUpotrebe && (
          <Paragraph size="sm" variant="secondary">
            Važi do: {dateFormatter.format(new Date(listing.rokUpotrebe))}
          </Paragraph>
        )}
        <Paragraph size="sm" variant="secondary">
          Objavljeno: {dateFormatter.format(new Date(listing.datumObjave))}
        </Paragraph>
      </div>
    </StyledCard>
  );
};

export const Listings = () => {
  const { data: preferredListings, error: preferredError } =
    useSWR<Listing[]>("oglasi");
  const { data: allListings, error } = useSWR<Listing[]>(
    "oglasi/preferirani/oglasi"
  );
  const { data: userData, error: userError } = useSWR<User>("korisnik/me");
  const recommendTime = localStorage?.getItem("recommendTimeout");

  if (error || userError || preferredError) return <ErrorMessage />;
  if (!allListings || !userData || !preferredListings)
    return <LoadingMessage />;

  const listings = allListings
    .filter((l) => l.stanjeOglasa === "AKTIVAN")
    .sort((a, b) => (dayjs(a.datumObjave) < dayjs(b.datumObjave) ? 1 : -1));

  const recommendedListings = preferredListings.filter(
    // TODO check for date difference
    (l) => {
      const diff =
        dayjs().diff(dayjs(l.vrijemeZatvaranja)) >
        1000 *
          ((recommendTime && Number.parseInt(recommendTime)) ||
            365 * 24 * 60 * 60);

      return l.primio === userData.email && l.vrijemeZatvaranja && diff;
    }
  );

  const canPublish =
    userData.roles?.[0] === "ROLE_ADMIN" ||
    userData.roles?.[0] === "ROLE_POTVRDENI_KORISNIK";

  if (!listings.length && (!recommendedListings.length || !canPublish))
    return (
      <Message
        title="Nema aktivnih oglasa"
        description="Trenutno nema aktivnih oglasa. Pričekaj da netko objavi oglas, ili dodaj svoj."
      />
    );

  // listings published 3 days ago or later
  const newListings = listings.filter(
    (l) =>
      dayjs(l.datumObjave).startOf("day") >
      dayjs().startOf("day").subtract(3, "days")
  );

  // rest of the listings
  const oldListings = listings.filter(
    (l) =>
      dayjs(l.datumObjave).startOf("day") <=
      dayjs().startOf("day").subtract(3, "days")
  );

  return (
    <div className="content-w d-flex flex-column align-items-stretch g-32">
      {canPublish && !!recommendedListings.length && (
        <div className="d-flex flex-column g-12 hide-empty">
          <Heading>Proslijedite donaciju</Heading>

          {recommendedListings.map((l) => (
            <ListingCard listing={l} colored key={l.id} />
          ))}
        </div>
      )}

      <div className="d-flex flex-column g-12 hide-empty">
        {!!newListings.length && (
          <Heading>{oldListings.length ? "Novi oglasi" : "Svi oglasi"}</Heading>
        )}

        {newListings.map((l) => (
          <ListingCard listing={l} key={l.id} />
        ))}
      </div>

      <div className="d-flex flex-column g-12 hide-empty">
        {!!oldListings.length && (
          <Heading>
            {newListings.length ? "Stariji oglasi" : "Svi oglasi"}
          </Heading>
        )}

        {oldListings.map((l) => (
          <ListingCard listing={l} key={l.id} />
        ))}
      </div>
    </div>
  );
};

export const UnpublishedListings = () => {
  const { data: allListings, error } = useSWR<Listing[]>("oglasi");

  if (error) return <ErrorMessage />;
  if (!allListings) return <LoadingMessage />;

  const listings = allListings
    .filter((l) => l.stanjeOglasa === "NEODOBREN")
    .sort((a, b) => (dayjs(a.datumObjave) < dayjs(b.datumObjave) ? 1 : -1));
  if (!listings.length)
    return (
      <Message
        title="Nema nepotvrđenih oglasa :)"
        description="Svi oglasi su potvrđeni. Novi oglasi pojaviti će se ovdje i čekati na odobrenje"
      />
    );

  return (
    <div className="content-w d-flex flex-column align-items-stretch g-32">
      <div className="d-flex flex-column g-12 hide-empty">
        <Heading>Nepotvrđeni oglasi</Heading>

        {listings.map((l) => (
          <ListingCard listing={l} key={l.id} />
        ))}
      </div>
    </div>
  );
};

const Banner = styled("img")`
  object-fit: cover;
  height: 200px;
  width: 100%;

  border: 1px solid ${({ theme }) => theme.border};
  border-radius: ${BorderRadius.md}px;
`;

const emailRegex = new RegExp(
  // eslint-disable-next-line no-useless-escape
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
);

export const ListingPage = () => {
  const [, params] = useRoute("/listings/:id");
  const listingId = params?.id;

  const [location, navigate] = useLocation();
  const { mutate } = useSWRConfig();

  const dateFormatter = new Intl.DateTimeFormat("hr", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const recommendTime = localStorage?.getItem("recommendTimeout");

  const { data: userData, error: userError } = useSWR<User>("korisnik/me");
  const { data: listing, error: listingError } = useSWR<Listing>(
    listingId ? `oglasi/${listingId}` : null
  );

  const [closeListing] = useMutation(`oglasi/zatvori/${listingId}`, true);
  const [deleteListing] = useMutation(`oglasi/${listingId}`, false, "DELETE");
  const [changeStatus] = useMutation(
    `oglasi/promjeniStanje/${listingId}`,
    true
  );

  if (listingError) return <Redirect to="/" />;
  if (!listingId || userError) return <ErrorMessage />;

  if (!listing || !userData) return <LoadingMessage />;

  const canPublish =
    userData.roles?.[0] === "ROLE_ADMIN" ||
    userData.roles?.[0] === "ROLE_POTVRDENI_KORISNIK";

  return (
    <div className="content-w d-flex flex-column">
      <div className="hide-empty mb-16 d-flex flex-column md-flex-row justify-content-end g-8">
        {/* TODO check for time */}
        {listing.primio === userData.email &&
          canPublish &&
          dayjs().diff(dayjs(listing.vrijemeZatvaranja)) >
            1000 *
              ((recommendTime && Number.parseInt(recommendTime)) ||
                365 * 24 * 60 * 60) && (
            <Button
              title="Ponovno doniraj"
              onClick={() => {
                history.pushState({ listing }, "", location + "/edit");
              }}
            />
          )}

        {userData.roles?.[0] === "ROLE_ADMIN" &&
          listing.stanjeOglasa === "NEODOBREN" && (
            <>
              <Button
                title="Pošalji na doradu"
                variant="secondary"
                onClick={() =>
                  changeStatus("ODBIJEN").then(() =>
                    mutate(`oglasi/${listingId}`)
                  )
                }
              />

              <Button
                title="Objavi"
                onClick={() =>
                  changeStatus("AKTIVAN").then(() =>
                    mutate(`oglasi/${listingId}`)
                  )
                }
              />
            </>
          )}

        {listing.korisnik?.email === userData.email &&
          listing.stanjeOglasa === "ODBIJEN" && (
            <>
              <Button
                title="Obriši oglas"
                variant="secondary"
                onClick={() => deleteListing().then(() => navigate("/my"))}
              />

              <Button
                title="Doradi oglas"
                onClick={() => {
                  history.pushState({ listing }, "", location + "/edit");
                }}
              />
            </>
          )}

        {listing.korisnik?.email === userData.email &&
          listing.stanjeOglasa === "AKTIVAN" && (
            <Button
              title="Zatvori oglas"
              onClick={() => {
                const email = prompt(
                  "Unesite e-mail adresu korisnika kojem ste donirali predmet."
                );

                if (!email) return null;
                if (!emailRegex.test(email))
                  return alert(
                    "Unjeli ste neispraan e-mail. Pokušajte ponovno s ispravnim e-mailom."
                  );

                closeListing(email).then(() => mutate(`oglasi/${listingId}`));
              }}
            />
          )}
      </div>

      {listing.slika && (
        <Banner
          src={`data:image/jpeg;base64,${listing.slika}`}
          className="mb-16"
        />
      )}

      <div className="d-flex flex-column md-flex-row g-16">
        <div className="flex-1 d-flex flex-column">
          <Heading>{listing.naslov}</Heading>

          <Paragraph className="mt-8">{listing.opis}</Paragraph>
        </div>
        <div className="flex-1 d-flex flex-column md-align-items-end">
          <div className="d-flex g-8 flex-wrap md-justify-content-end">
            {!!listing.predivdenSpol && (
              <Badge>spol: {sexMessages[listing.predivdenSpol]}</Badge>
            )}

            {!!listing.predvidenaDob && (
              <Badge>predviđena dob: {listing.predvidenaDob}</Badge>
            )}

            <Badge>stanje: {conditionMessages[listing.stanjePredmeta]}</Badge>
          </div>

          <div className="d-flex flex-column mt-16 md-align-items-end">
            {listing.rokUpotrebe && (
              <Paragraph size="sm">
                Važi do: {dateFormatter.format(new Date(listing.rokUpotrebe))}
              </Paragraph>
            )}
            <Paragraph size="sm">
              Objavljeno: {dateFormatter.format(new Date(listing.datumObjave))}
            </Paragraph>
            {listing.korisnik && (
              <Paragraph size="sm">
                Autor: {listing.korisnik.ime} {listing.korisnik.prezime}
              </Paragraph>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
