import { Link } from "wouter";

import { styled } from "@/ui/theme";
import { Heading, Paragraph } from "@/ui/typography";
import { useAuth } from "@/auth";
import useSWR, { useSWRConfig } from "swr";
import { Icon } from "@/ui/icons";
import { Card } from "@/ui/cards";
import { useMutation } from "@/swr";
import { User } from "@/types/listings";

const HEADER_HEIGHT = 64;

const HeaderContainer = styled("div")`
  position: fixed;
  height: ${HEADER_HEIGHT}px;
  top: 0;
  left: 0;
  right: 0;
  z-index: 10;

  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  background-color: ${({ theme }) => theme.surface};
  border-bottom: 1px solid ${({ theme }) => theme.border};
`;

const HeaderPadding = styled("div")`
  height: ${HEADER_HEIGHT}px;
`;

const AvatarContainer = styled("div")`
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;

  padding: 8px;

  .dropdown {
    display: none;
    /* display: flex; */
  }

  &:hover,
  &:focus {
    .dropdown {
      display: flex;
    }
  }
`;

const StyledDropdown = styled(Card)`
  position: absolute;
  top: 44px;
  right: 8px;
  padding: 0;
  overflow: hidden;
  min-width: 200px;

  flex-direction: column;

  > *:not(:last-child) {
    border-bottom: 1px solid ${({ theme }) => theme.border};
  }
`;

const DropdownItem = styled("div")<{ $clickable?: boolean; as?: string }>`
  padding: 8px 16px;
  margin: 0;
  border: 0;
  background-color: transparent;
  text-align: left;

  white-space: nowrap;
  ${({ $clickable: $hasPointer }) => $hasPointer && "cursor: pointer"};

  &:hover {
    background-color: ${({ theme, $clickable }) =>
      $clickable && theme.neutral[15]};
  }

  &:active {
    background-color: ${({ theme, $clickable }) =>
      $clickable && theme.neutral[25]};
  }
`;

const Dropdown = () => {
  const { logout } = useAuth();
  const { cache } = useSWRConfig();

  const { data } = useSWR<User>("korisnik/me");
  const { data: user } = useSWR<User>(
    data?.email ? `korisnik/${data.email}` : null
  );
  const [deleteAccount] = useMutation(
    `korisnik/${data?.email}`,
    false,
    "DELETE"
  );

  if (!user || !data) return null;

  const isAdmin = data?.roles?.[0] === "ROLE_ADMIN";
  const isValidated = data?.roles?.[0] === "ROLE_POTVRDENI_KORISNIK" || isAdmin;

  const handleDeleteAccount = async () => {
    const shouldDelete = window.confirm(
      "Želiš li zaista obrisati račun? Ako potvrdiš, svi tvoji podaci bit će trajno obrisani."
    );

    if (!shouldDelete) return;

    await deleteAccount();
    logout();
  };

  const handleLogout = async () => {
    await logout();
    // @ts-expect-error wrong typedefs in swr
    cache.clear();
  };

  return (
    <StyledDropdown as="div" elevated className="dropdown">
      <DropdownItem>
        <Paragraph bold>{data?.email}</Paragraph>
      </DropdownItem>

      {isAdmin && (
        <Link href="/users" onClick={() => document.body.focus()}>
          <DropdownItem $clickable>
            <Paragraph>Popis korisnika</Paragraph>
          </DropdownItem>
        </Link>
      )}

      {isAdmin && (
        <Link
          href="/unpublished-listings"
          onClick={() => document.body.focus()}
        >
          <DropdownItem $clickable>
            <Paragraph>Nepotvrđeni oglasi</Paragraph>
          </DropdownItem>
        </Link>
      )}

      {isValidated && (
        <Link href="/my" onClick={() => document.body.focus()}>
          <DropdownItem $clickable>
            <Paragraph>Moji oglasi</Paragraph>
          </DropdownItem>
        </Link>
      )}

      <Link href="/my-interests" onClick={() => document.body.focus()}>
        <DropdownItem $clickable>
          <Paragraph>Moji interesi</Paragraph>
        </DropdownItem>
      </Link>

      <DropdownItem
        as="button"
        onClick={() => history.pushState(user, "", "/edit-profile")}
        $clickable
      >
        <Paragraph>Uredi profil</Paragraph>
      </DropdownItem>

      {!isAdmin && (
        <DropdownItem as="button" onClick={handleDeleteAccount} $clickable>
          <Paragraph>Obriši račun</Paragraph>
        </DropdownItem>
      )}

      <DropdownItem as="button" onClick={handleLogout} $clickable>
        <Paragraph>Odjavi se</Paragraph>
      </DropdownItem>
    </StyledDropdown>
  );
};

const DropdownAvatar = () => {
  return (
    <AvatarContainer tabIndex={1}>
      <Icon name="avatar" size={36} />

      <Dropdown />
    </AvatarContainer>
  );
};

export const Header = () => {
  return (
    <>
      <HeaderPadding />
      <HeaderContainer>
        <Heading size="sm">
          <Link href="/" onClick={() => window.scrollTo({ top: 0 })}>
            Doniraj
          </Link>
        </Heading>

        <DropdownAvatar />
      </HeaderContainer>
    </>
  );
};
