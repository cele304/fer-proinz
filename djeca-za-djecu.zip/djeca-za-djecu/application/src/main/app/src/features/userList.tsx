import { useMutation } from "@/swr";
import { User } from "@/types/listings";
import { Card } from "@/ui/cards";
import { styled } from "@/ui/theme";
import { Paragraph } from "@/ui/typography";
import useSWR, { useSWRConfig } from "swr";
import { ErrorMessage, LoadingMessage } from "./messages";

const StyledListItem = styled("div")`
  gap: 32px;

  &:not(:last-child) {
    border-bottom: 1px solid ${({ theme }) => theme.border};
  }
`;

const UserListItem = ({ user }: { user: User }) => {
  const { mutate } = useSWRConfig();

  const [setValidated, isLoading] = useMutation(
    `korisnik/dozvoli/${user.email}`,
    true
  );

  const isValidated = user.roles?.[0] === "ROLE_POTVRDENI_KORISNIK";

  const handleValidation = () => {
    setValidated(
      isValidated ? "ROLE_NEPOTVRDENI_KORISNIK" : "ROLE_POTVRDENI_KORISNIK"
    ).then(() => mutate("korisnik"));
  };

  return (
    <StyledListItem className="d-flex justify-content-between p-12">
      <Paragraph size="md" bold className="text-truncate">
        {user.email} - {user.ime} {user.prezime}
      </Paragraph>

      <Paragraph
        size="sm"
        bold
        as="label"
        className="d-flex align-items-center"
        variant={isLoading ? "secondary" : "primary"}
      >
        {user.roles?.[0] === "ROLE_ADMIN" ? (
          <>Administrator</>
        ) : (
          <>
            Validiran
            <input
              disabled={isLoading}
              type="checkbox"
              className="ml-8"
              checked={isValidated}
              onClick={handleValidation}
            />
          </>
        )}
      </Paragraph>
    </StyledListItem>
  );
};

const UserList = () => {
  const { data: users, error } = useSWR<User[]>("korisnik");

  if (error) return <ErrorMessage />;
  if (!users) return <LoadingMessage />;

  return (
    <Card className="content-w p-0">
      {users.map((u) => (
        <UserListItem user={u} key={u.email}></UserListItem>
      ))}
    </Card>
  );
};

export default UserList;
