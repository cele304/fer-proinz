import { styled } from "@/ui/theme";
import { Card } from "@/ui/cards";
import { Heading, Paragraph } from "@/ui/typography";
import useSWR, { useSWRConfig } from "swr";
import { ErrorMessage, LoadingMessage } from "./messages";
import { useMutation } from "@/swr";
import { useState } from "react";

const Container = styled(Card)`
  flex: 1;
  max-width: min(480px, calc(100% - 32px));

  max-height: calc(100vh - 32px);

  display: flex;
  flex-direction: column;
  margin: 16px;
  padding: 16px 0;
`;

const ContentContainer = styled("div")`
  padding: 16px 24px 8px;
  overflow-y: auto;
`;

const InterestListItem = ({
  name,
  interests,
  handleSelect,
  disabled,
}: {
  name: string;
  interests: string[];
  handleSelect: (name: string, newVal: boolean) => unknown;
  disabled: boolean;
}) => {
  const isSelected = interests.includes(name);

  return (
    <Paragraph as="label">
      <input
        type="checkbox"
        checked={isSelected}
        onClick={() => handleSelect(name, !isSelected)}
        className="mr-8"
        disabled={disabled}
      />
      {name}
    </Paragraph>
  );
};

export const InterestArrangementForm = () => {
  const { mutate } = useSWRConfig();
  const {
    data: interests,
    error,
    isValidating,
  } = useSWR<{ naziv: string }[]>("korisnik/getinteresi");

  const [isLoadingMutation, setLoading] = useState(false);

  const [addInterest] = useMutation("korisnik/updateinteresi");
  const [deleteInterest] = useMutation(
    "korisnik/deleteinteresi",
    false,
    "DELETE"
  );

  if (error) return <ErrorMessage />;
  if (!interests) return <LoadingMessage />;

  const interestKeys = interests.map((i) => i?.naziv);
  const isLoading = isValidating || isLoadingMutation;

  const handleSubmit = async (name: string, newVal: boolean) => {
    setLoading(true);

    try {
      await (newVal ? addInterest : deleteInterest)([name]);
      await mutate("korisnik/getinteresi");
      mutate("oglasi/preferirani/oglasi", null);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 align-self-stretch d-flex align-items-center justify-content-center">
      <Container>
        <Heading center size="sm">
          Uređivanje interesa
        </Heading>

        <hr className="mt-12" />

        <ContentContainer>
          <Paragraph as="p" bold>
            Igračke
          </Paragraph>

          <div className="d-flex flex-column ml-16">
            <InterestListItem
              name="Lego kocke"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Plišane igračke"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Lutke"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />
          </div>

          <Paragraph as="p" bold className="mt-8">
            Kolica
          </Paragraph>

          <div className="d-flex flex-column ml-16">
            <InterestListItem
              name="3 u 1"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Kišobran kolica"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Dodaci za kolica"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />
          </div>

          <Paragraph as="p" bold className="mt-8">
            Namještaj
          </Paragraph>

          <div className="d-flex flex-column ml-16">
            <InterestListItem
              name="Kreveti"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Hranilice"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Komode za prematenje"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />
          </div>

          <Paragraph as="p" bold className="mt-8">
            Odjeća
          </Paragraph>

          <div className="d-flex flex-column ml-16">
            <InterestListItem
              name="Majce"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Hlače"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />

            <InterestListItem
              name="Cipele"
              handleSelect={handleSubmit}
              interests={interestKeys}
              disabled={isLoading}
            />
          </div>
        </ContentContainer>
      </Container>
    </div>
  );
};
