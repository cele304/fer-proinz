import { FormEventHandler } from "react";
import { Link, useLocation } from "wouter";
import dayjs from "dayjs";

import { useMutation } from "@/swr";
import { useAuth } from "@/auth";
import { styled } from "@/ui/theme";
import { Button } from "@/ui/buttons";
import { Card } from "@/ui/cards";
import { Field, Input, Select } from "@/ui/form";
import { Heading, Paragraph } from "@/ui/typography";
import { User } from "@/types/listings";
import { useSWRConfig } from "swr";

const Container = styled(Card)`
  flex: 1;
  max-width: min(480px, calc(100% - 32px));

  max-height: calc(100vh - 32px);

  display: flex;
  flex-direction: column;
  margin: 16px;
  padding: 16px 0;
`;

const ContentContainer = styled("div")`
  padding: 16px 24px 8px;
  overflow-y: auto;
`;

const ErrorText = styled(Paragraph)`
  color: #c34343;
`;

const ErrorPlaceholder = styled("div")`
  height: 22px;
`;

export const RegisterForm = () => {
  const { mutate } = useSWRConfig();
  const monthFormatteer = new Intl.DateTimeFormat("hr", {
    month: "long",
  });

  const [, navigate] = useLocation();
  const user = history.state as User | null;
  const isEdit = !!user;

  const [register, isLoading, error] = useMutation(
    isEdit ? "korisnik/update" : "korisnik/signup"
  );
  const { login } = useAuth();

  const handleSubmit: FormEventHandler = async (e) => {
    e.preventDefault();

    const {
      email,
      password,
      firstName,
      lastName,
      mobileNumber,
      city,
      zip,
      street,
      sex,
      month,
      day,
      year,
    } = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as {
      email: string;
      password: string;
      firstName: string;
      lastName: string;
      mobileNumber: string;
      city: string;
      zip: string;
      street: string;
      sex: string;
      day: string;
      month: string;
      year: string;
    };

    await register({
      email: email,
      lozinka: password,
      ime: firstName,
      prezime: lastName,
      brojMobitela: mobileNumber,
      adresa: { grad: city, zipcode: zip, ulica: street },
      dijete: [
        {
          spol: sex,
          datumRodjenja: `${year}-${month.padStart(2, "0")}-${day.padStart(
            2,
            "0"
          )}`,
        },
      ],
    });

    !isEdit && (await login(email, password));
    isEdit && mutate(`korisnik/${user.email}`, null);
    isEdit && navigate("/");
  };

  const childBirth = user?.dijete?.[0]?.datumRodjenja
    ? dayjs(user.dijete[0].datumRodjenja)
    : undefined;

  return (
    <div className="flex-1 align-self-stretch d-flex align-items-center justify-content-center">
      <Container as="form" onSubmit={handleSubmit}>
        <Heading center size="sm">
          {isEdit ? "Uređivanje profila" : "Registracija"}
        </Heading>

        <hr className="mt-12" />

        <ContentContainer>
          <Paragraph as="p" bold>
            Osobni podaci
          </Paragraph>

          <div>
            {!isEdit && (
              <>
                <Field label="Email" required>
                  <Input
                    type="email"
                    name="email"
                    autoComplete="username"
                    required
                  />
                </Field>

                <Field label="Zaporka" required>
                  <Input
                    type="password"
                    name="password"
                    required
                    autoComplete="current-password"
                  />
                </Field>
              </>
            )}

            <div className="d-flex g-8">
              <Field label="Ime" required className="minw-0">
                <Input
                  type="text"
                  name="firstName"
                  defaultValue={user?.ime}
                  required
                />
              </Field>

              <Field label="Prezime" required className="minw-0">
                <Input
                  type="text"
                  name="lastName"
                  defaultValue={user?.prezime}
                  required
                />
              </Field>
            </div>

            <Field label="Broj mobitela" required>
              <Input
                type="text"
                name="mobileNumber"
                defaultValue={user?.brojMobitela}
                required
              />
            </Field>

            <div className="d-flex g-8">
              <Field label="Grad" required className="minw-0">
                <Input
                  type="text"
                  name="city"
                  defaultValue={user?.adresa?.grad}
                  required
                />
              </Field>

              <Field label="Poštanski broj" required className="minw-0">
                <Input
                  type="text"
                  name="zip"
                  defaultValue={user?.adresa?.zipcode}
                  required
                />
              </Field>
            </div>

            <Field label="Ulica" required>
              <Input
                type="text"
                name="street"
                defaultValue={user?.adresa?.ulica}
                required
              />
            </Field>
          </div>

          <Paragraph as="p" bold className="mt-24">
            Podaci o djetetu
          </Paragraph>

          <div>
            <Field label="Spol" required>
              <Select
                name="sex"
                defaultValue={user?.dijete?.[0]?.spol || undefined}
              >
                <option value="M">muško</option>
                <option value="F">žensko</option>
              </Select>
            </Field>

            <Field label="Datum rođenja" required>
              <div className="d-flex g-8">
                <Select
                  name="day"
                  className="flex-1"
                  defaultValue={childBirth?.date()?.toString()}
                >
                  {[...Array(31)].map((_v, i) => (
                    <option key={i} value={i + 1}>
                      {i + 1}.
                    </option>
                  ))}
                </Select>

                <Select
                  name="month"
                  className="flex-1"
                  defaultValue={(childBirth?.month
                    ? childBirth.month() + 1
                    : undefined
                  )?.toString()}
                >
                  {[...Array(12)].map((_v, i) => (
                    <option key={i} value={i + 1}>
                      {monthFormatteer.format(new Date(Date.UTC(2000, i % 12)))}
                    </option>
                  ))}
                </Select>

                <Select
                  name="year"
                  className="flex-1"
                  defaultValue={childBirth?.year().toString()}
                >
                  {[...Array(20)].map((_v, i) => (
                    // allow for children up to 18 years old (and next year's unborns)
                    <option key={i} value={dayjs().year() + 1 - i}>
                      {dayjs().year() + 1 - i}.
                    </option>
                  ))}
                </Select>
              </div>
            </Field>
          </div>
        </ContentContainer>

        <div className="d-flex flex-column pl-24 pr-24">
          {error ? (
            <ErrorText size="sm">
              Molimo provjeri sva polja i pokušaj ponovo.
            </ErrorText>
          ) : (
            <ErrorPlaceholder />
          )}

          <Button
            type="submit"
            title={isEdit ? "Spremi izmjene" : "Registriraj se"}
            loading={isLoading}
            loadingTitle="Registriracija..."
          />
          {!isEdit && (
            <Paragraph size="sm" center className="mt-12">
              Već imaš račun? <Link to="/login">Prijavi se</Link>
            </Paragraph>
          )}
        </div>
      </Container>
    </div>
  );
};
