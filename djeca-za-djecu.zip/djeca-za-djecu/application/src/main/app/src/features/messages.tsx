import { ComponentPropsWithoutRef, ReactNode } from "react";
import { Link } from "wouter";

import { styled } from "@/ui/theme";
import { Heading, Paragraph } from "@/ui/typography";

const MessageWrapper = styled("div")`
  flex: 1;

  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  max-width: 600px;
  margin: 32px;
`;

interface MessageProps extends ComponentPropsWithoutRef<typeof MessageWrapper> {
  title: string;
  description: ReactNode;
}

export const Message = ({ title, description, ...props }: MessageProps) => (
  <MessageWrapper {...props}>
    <Heading center>{title}</Heading>
    <Paragraph center>{description}</Paragraph>
  </MessageWrapper>
);

export const ErrorMessage = () => (
  <MessageWrapper>
    <Heading center>Nešto je pošlo po zlu!</Heading>
    <Paragraph center>
      Izgleda da se dogodila greška. Probaj osvježiti stranicu.
    </Paragraph>
  </MessageWrapper>
);

export const LoadingMessage = () => (
  <MessageWrapper>
    <Heading center>Učitavanje...</Heading>
  </MessageWrapper>
);

export const E404Message = () => (
  <MessageWrapper>
    <Heading center>404</Heading>
    <Paragraph center>Ups! Izgleda da ovdje nema ničega.</Paragraph>
    <Paragraph center>
      Vrati se na <Link href="/">početnu stranicu</Link>.
    </Paragraph>
  </MessageWrapper>
);
