import { FormEventHandler } from "react";
import dayjs from "dayjs";

import { useMutation } from "@/swr";
import { styled } from "@/ui/theme";
import { Button } from "@/ui/buttons";
import { Card } from "@/ui/cards";
import { Field, Input, Select } from "@/ui/form";
import { Heading, Paragraph } from "@/ui/typography";
import useSWR from "swr";
import { useLocation } from "wouter";
import { Listing } from "@/types/listings";

const Container = styled(Card)`
  flex: 1;
  max-width: min(480px, calc(100% - 32px));

  max-height: calc(100vh - 64px - 32px);

  display: flex;
  flex-direction: column;
  margin: 16px;
  padding: 16px 0;
`;

const ContentContainer = styled("div")`
  padding: 16px 24px 8px;
  overflow-y: auto;
`;

const ErrorText = styled(Paragraph)`
  color: #c34343;
`;

const ErrorPlaceholder = styled("div")`
  height: 22px;
`;

const getBase64 = (file: File) =>
  new Promise((resolve, reject) => {
    if (!file.size) resolve(undefined);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      // backend only needs the data part of base64 encoding (without the headers)
      resolve(
        reader.result
          ?.toString()
          .substring(reader.result.toString().indexOf(",") + 1)
      );
    };
    reader.onerror = (error) => reject(error);
  });

export const NewListingForm = () => {
  const monthFormatteer = new Intl.DateTimeFormat("hr", {
    month: "long",
  });

  const defaultListing = history.state?.listing as Listing | undefined;

  const [, setLocation] = useLocation();

  const [deleteListing, isLoadingDelete] = useMutation(
    `oglasi/${defaultListing?.id}`,
    false,
    "DELETE"
  );
  const [createListing, isLoadingCreate, error] = useMutation("oglasi");

  const { data } = useSWR("korisnik/me");

  const isLoading = isLoadingDelete || isLoadingCreate;

  const handleSubmit: FormEventHandler = async (e) => {
    e.preventDefault();

    const {
      title,
      description,
      image,
      condition,
      expected_age,
      expected_sex,
      year,
      month,
      day,
      subcategory,
    } = Object.fromEntries(new FormData(e.target as HTMLFormElement)) as {
      title: string;
      description: string;
      image: File;
      condition: string;
      expected_age: string;
      expected_sex: string;
      subcategory: string;
      year: string;
      month: string;
      day: string;
    };

    // 2023-01-01T00:00:00.000+00:00

    const success = await createListing({
      naslov: title,
      opis: description,
      slika: (await getBase64(image)) || defaultListing?.slika,
      datumObjave: dayjs().toISOString(),
      stanjePredmeta: condition,
      predvidenaDob: expected_age,
      predivdenSpol: expected_sex,
      rokUpotrebe: `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`,
      korisnik: { email: data?.email },
      podkategorija: { naziv: subcategory },
    });

    if (success) {
      defaultListing && (await deleteListing());
      setLocation("/my");
    }
  };

  return (
    <div className="flex-1 align-self-stretch d-flex align-items-center justify-content-center">
      <Container as="form" onSubmit={handleSubmit}>
        <Heading center size="sm">
          {defaultListing
            ? defaultListing.primio
              ? "Ponovno doniranje"
              : "Dorada oglasa"
            : "Kreiranje oglasa"}
        </Heading>

        <hr className="mt-12" />

        <ContentContainer>
          <Paragraph as="p" bold>
            Podaci o predmetu
          </Paragraph>

          <div>
            <Field label="Naslov" required>
              <Input
                type="title"
                name="title"
                defaultValue={defaultListing?.naslov}
                required
              />
            </Field>

            <Field label="Opis" required>
              <Input
                type="description"
                name="description"
                defaultValue={defaultListing?.opis}
                required
              />
            </Field>

            <Field label="Slika">
              <input type="file" name="image" accept="image/jpeg, image/png" />

              <Paragraph size="sm">Max. veličina slike: 600KiB</Paragraph>

              {defaultListing?.slika && (
                <Paragraph size="sm">
                  Postoji prethodno odabrana slika koja će se prepisati ako
                  odaberete novu.
                </Paragraph>
              )}
            </Field>

            <Field label="Stanje" required>
              <Select
                name="condition"
                defaultValue={defaultListing?.stanjePredmeta}
              >
                <option value="NOVO">novo</option>
                <option value="MALO_KORIŠTENO">malo korišteno</option>
                <option value="SREDNJE_KORIŠTENO">srednje korišteno</option>
                <option value="JAKO_KORIŠTENO">jako korišteno</option>
              </Select>
            </Field>

            <Field label="Predviđena dob">
              <Input
                type="expected_age"
                name="expected_age"
                defaultValue={defaultListing?.predvidenaDob}
              />
            </Field>

            <Field label="Predviđen spol" required>
              <Select
                name="expected_sex"
                defaultValue={defaultListing?.predivdenSpol}
              >
                <option value="M">muško</option>
                <option value="Ž">žensko</option>
                <option value="UNISEX">unisex</option>
              </Select>
            </Field>

            <Field label="Rok upotrebe" required>
              <div className="d-flex g-8">
                <Select
                  name="day"
                  className="flex-1"
                  defaultValue={
                    defaultListing?.rokUpotrebe &&
                    dayjs(defaultListing.rokUpotrebe).day()
                  }
                >
                  {[...Array(31)].map((_v, i) => (
                    <option key={i} value={i + 1}>
                      {i + 1}.
                    </option>
                  ))}
                </Select>

                <Select
                  name="month"
                  className="flex-1"
                  defaultValue={
                    defaultListing?.rokUpotrebe &&
                    dayjs(defaultListing.rokUpotrebe).month()
                  }
                >
                  {[...Array(12)].map((_v, i) => (
                    <option key={i} value={i + 1}>
                      {monthFormatteer.format(new Date(Date.UTC(2000, i % 12)))}
                    </option>
                  ))}
                </Select>

                <Select
                  name="year"
                  className="flex-1"
                  defaultValue={
                    defaultListing?.rokUpotrebe &&
                    dayjs(defaultListing.rokUpotrebe).year()
                  }
                >
                  {[...Array(10)].map((_v, i) => (
                    <option key={i} value={dayjs().year() + i}>
                      {dayjs().year() + i}.
                    </option>
                  ))}
                </Select>
              </div>
            </Field>

            <Field label="Kategorija" required>
              <Select name="subcategory">
                <optgroup label="Igračke">
                  <option>Lego kocke</option>
                  <option>Plišane igračke</option>
                  <option>Lutke</option>
                </optgroup>

                <optgroup label="Kolica">
                  <option>3 u 1</option>
                  <option>Kišobran kolica</option>
                  <option>Dodaci za kolica</option>
                </optgroup>

                <optgroup label="Namještaj">
                  <option>Kreveti</option>
                  <option>Hranilice</option>
                  <option>Komode za prematenje</option>
                </optgroup>

                <optgroup label="Odjeća">
                  <option>Majce</option>
                  <option>Hlače</option>
                  <option>Cipele</option>
                </optgroup>
              </Select>
            </Field>
          </div>
        </ContentContainer>

        <div className="d-flex flex-column pl-24 pr-24">
          {error ? (
            <ErrorText size="sm">
              Molimo provjeri sva polja i pokušaj ponovo.
            </ErrorText>
          ) : (
            <ErrorPlaceholder />
          )}

          <Button
            type="submit"
            title={
              defaultListing
                ? defaultListing.primio
                  ? "Doniraj opet"
                  : "Spremi izmjene"
                : "Kreiraj oglas"
            }
            loading={isLoading}
            loadingTitle="Učitavanje..."
          />
        </div>
      </Container>
    </div>
  );
};
