import useSWR from "swr";

import { Listing } from "@/types/listings";
import { Heading, Paragraph } from "@/ui/typography";
import { ListingCard } from "./listings";
import { ErrorMessage, LoadingMessage, Message } from "./messages";
import { Link } from "wouter";
import dayjs from "dayjs";

export const My = () => {
  const { data: listings, error } = useSWR<Listing[]>("oglasi/moji-oglasi");

  if (error) return <ErrorMessage />;
  if (!listings) return <LoadingMessage />;

  if (!listings.length)
    return (
      <>
        <Message
          title="Nema oglasa"
          description={
            <>
              <span className="mr-4">
                Nemate niti jedan oglas. Dodajte oglas klikom na
              </span>
              <Link href="/my/new">novi oglas</Link>
            </>
          }
        />
      </>
    );

  return (
    <div className="content-w d-flex flex-column align-items-stretch g-12">
      <div className="d-flex align-items-center justify-content-between">
        <Heading>Moji oglasi</Heading>
        <Paragraph>
          <Link href="/my/new">novi oglas</Link>
        </Paragraph>
      </div>

      {listings
        .sort((a, b) => (dayjs(a.datumObjave) < dayjs(b.datumObjave) ? 1 : -1))
        .map((l) => (
          <ListingCard listing={l} showStatus key={l.id} />
        ))}
    </div>
  );
};
