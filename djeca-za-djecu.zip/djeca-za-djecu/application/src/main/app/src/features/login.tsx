import { FormEventHandler, useState } from "react";
import { Link } from "wouter";

import { useAuth } from "@/auth";
import { styled } from "@/ui/theme";
import { Button } from "@/ui/buttons";
import { Card } from "@/ui/cards";
import { Field, Input } from "@/ui/form";
import { Heading, Paragraph } from "@/ui/typography";

const Container = styled(Card)`
  flex: 1;
  max-width: 350px;

  display: flex;
  flex-direction: column;
  margin: 16px;
  padding: 16px 0;
`;

const ErrorText = styled(Paragraph)`
  color: #c34343;
`;

const ErrorPlaceholder = styled("div")`
  height: 22px;
`;

const errorMessages = {
  invalid_auth: "Email ili zaporka su neispravni.",
  unknown_error: "Dogodila se greška. Pokušajte ponovno.",
};

export const LoginForm = () => {
  const { login } = useAuth();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<keyof typeof errorMessages>();

  const handleSubmit: FormEventHandler = async (e) => {
    e.preventDefault();

    const { email, password } = Object.fromEntries(
      new FormData(e.target as HTMLFormElement)
    ) as { email: string; password: string };

    setLoading(true);
    const loginRes = await login(email, password);
    if (loginRes) setError(loginRes);
    setLoading(false);
  };

  return (
    <div className="flex-1 align-self-stretch d-flex align-items-center justify-content-center">
      <Container as="form" onSubmit={handleSubmit}>
        <Heading center size="sm">
          Prijava
        </Heading>
        <hr className="mt-12 mb-16" />

        <div className="pl-24 pr-24">
          <Field label="Email">
            <Input
              type="text"
              name="email"
              autoComplete="username"
              aria-required
            />
          </Field>

          <Field label="Zaporka">
            <Input
              type="password"
              name="password"
              aria-required
              autoComplete="current-password"
            />
          </Field>
        </div>

        <div className="d-flex flex-column mt-8 pl-24 pr-24">
          {error ? (
            <ErrorText size="sm">{errorMessages[error]}</ErrorText>
          ) : (
            <ErrorPlaceholder />
          )}

          <Button
            type="submit"
            title="Prijavi se"
            loading={loading}
            loadingTitle="Prijavljivanje..."
          />
        </div>

        <Paragraph size="sm" center className="mt-12">
          Nemaš račun? <Link to="/register">Registriraj se</Link>
        </Paragraph>
      </Container>
    </div>
  );
};
