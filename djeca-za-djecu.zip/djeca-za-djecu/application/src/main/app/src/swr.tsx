import { ComponentPropsWithoutRef, useState } from "react";
import { SWRConfiguration, mutate, SWRConfig } from "swr";

import { useAuth } from "./auth";

export const API_HOST = import.meta.env.VITE_API_HOST;

const useFetcher = () => {
  const { isLoggedIn, authToken, forceLogout } = useAuth();

  return (uri: string, opts?: RequestInit) =>
    fetch(`${API_HOST}/${uri}`, {
      ...opts,
      headers: isLoggedIn
        ? { ...opts?.headers, Authorization: `Bearer ${authToken}` }
        : opts?.headers,
    }).then((res) => {
      if (res.status === 403) forceLogout();
      if (!res.ok) throw new Error("not ok :/");
      return res.json();
    });
};

export const usePrefetch = () => {
  const fetcher = useFetcher();
  return async (key: string) => await mutate(key, fetcher(key));
};

export const useMutation = <T extends boolean>(
  key: string,
  isPlainText?: T,
  method: "POST" | "DELETE" = "POST"
) => {
  const { authToken } = useAuth();

  const [hasError, setError] = useState(false);
  const [isLoading, setLoading] = useState(false);

  const mutate = async (
    input?: T extends true ? string : Record<string, unknown> | unknown[]
  ) => {
    setError(false);
    setLoading(true);

    try {
      const res = await fetch(`${API_HOST}/${key}`, {
        method: method,
        headers: {
          Accept: "application/json",
          "Content-Type": isPlainText ? "text/plain" : "application/json",
          ...(!!authToken && { Authorization: `Bearer ${authToken}` }),
        },
        // @ts-expect-error body does accept string, wrong typedefs ig
        body: isPlainText ? input : JSON.stringify(input),
      });

      if (!res.ok) {
        setError(true);
        setLoading(false);
        return false;
      }
    } catch (e) {
      setError(true);
      setLoading(false);
      return false;
    }

    setLoading(false);
    return true;
  };

  return [mutate, isLoading, hasError] as const;
};

export const SwrProvider = (
  props: Omit<ComponentPropsWithoutRef<typeof SWRConfig>, "value">
) => {
  const fetcher = useFetcher();

  const config: SWRConfiguration = {
    fetcher,
    shouldRetryOnError: false,
    focusThrottleInterval: 500,
    onError: (err, key) =>
      console.error(`error: ${err} occurred when fetching ${key}`),
  };

  return <SWRConfig value={config} {...props} />;
};
