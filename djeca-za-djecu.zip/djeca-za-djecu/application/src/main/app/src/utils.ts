/** merges multiple `classNames` into a single string
 * @param args - variable arguments list of `classNames` to merge
 * @remarks will filter out any non-string values
 * @example
 * ```tsx
 * const Button = ({ className, loading }) => (
 *   <button className={mcn(className, loading && "is-loading", "button")}>
 *     Click me!
 *   </button>
 * )
 * ```
 */
export const mcn = (...args: unknown[]) =>
  args.filter((arg) => typeof arg === "string").join(" ");

/** Return `res` when `condition` is true, otherwise return `undefined`
 * @remarks shorthand for ternary `condition ? res : undefined`
 */
export const when = <T>(condition: unknown, res: T) =>
  condition ? res : undefined;
