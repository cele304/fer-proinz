import {
  styled as gStyled,
  // defined in `goober.d.ts`
  DefaultTheme,
  StyledFunction,
  ForwardRefFunction,
} from "goober";
import { useEffect, useState } from "react";

type HSL = `hsl(${number}, ${number}%, ${number}%)`;
type HSLA = `hsla(${number}, ${number}%, ${number}%, ${number})`;
type HEX = `#${string}`;
export type color = HSL | HSLA | HEX;

// generated from #9ab191
const primary = {
  15: "#F6F8F5",
  25: "#EEF2EC",
  50: "#DDE5DA",
  75: "#BBCBB5",
  85: "#8FA486",
  100: "#82967B",
  200: "#778970",
  300: "#6B7B64",
  400: "#606F5B",
  500: "#55624F",
  600: "#3F4A3B",
  700: "#2B3228",
  800: "#21281F",
  900: "#181D16",
};

const neutral = {
  0: "white",
  15: "#f8f8f8",
  25: "#f1f1f1",
  50: "#e2e2e2",
  75: "#c6c6c6",
  85: "#ababab",
  100: "#919191",
  200: "#848484",
  300: "#767676",
  400: "#6f6f6f",
  500: "#5e5e5e",
  600: "#3b3b3b",
  700: "#262626",
  800: "#1b1b1b",
  900: "#111",
  1000: "black",
};

const scheme = {
  background: neutral[15],
  surface: neutral[0],
  border: neutral[50],
  scrim: "hsla(0, 0%, 0%, 0.1)",

  typography: {
    primary: neutral[800],
    secondary: neutral[300],
    colored: primary[400],
    coloredDark: primary[600],
    onPrimary: neutral[0],
  },

  primary,
  neutral,
} as const;

export const useTheme = (): DefaultTheme => scheme;

export const useBreakpoints = (): {
  md: boolean;
  lg: boolean;
  current: "sm" | "md" | "lg";
} => {
  const [isMd, setMd] = useState(window.innerWidth >= Breakpoints.md);
  const [isLg, setLg] = useState(window.innerWidth >= Breakpoints.lg);

  useEffect(() => {
    const action = () => {
      setMd(window.innerWidth >= Breakpoints.md);
      setLg(window.innerWidth >= Breakpoints.lg);
    };

    window.addEventListener("resize", action);
    return () => {
      window.removeEventListener("resize", action);
    };
  }, []);

  return { md: isMd, lg: isLg, current: isMd ? "md" : isLg ? "lg" : "sm" };
};

export const enum Breakpoints {
  md = 600,
  lg = 1240,
}

export const enum BorderRadius {
  sm = 4,
  md = 8,
  lg = 16,
}

export const enum Shadows {
  md = "box-shadow: 16px 16px 48px 48px rgba(0, 0, 0, 0.04);",
}

export const enum Opacities {
  disabled = 0.6,
  loading = 0.8,
}

export const enum Weights {
  normal = 400,
  semi = 500,
  bold = 700,
}

// DEPENDS ON USING VITE
// when in debug, add displayNames to goober's styled
const devStyled = (
  tag: keyof JSX.IntrinsicElements,
  forwardRef: ForwardRefFunction
): ReturnType<typeof gStyled> => {
  // get the tag name off of passed in component
  const displayName =
    typeof tag === "string"
      ? `go-${tag}`
      : typeof tag === "function"
      ? `go-${
          (tag as Record<string, unknown>).displayName ||
          (tag as Record<string, unknown>).name ||
          "Unknown"
        }`
      : "go-Invalid";

  const addDisplayName: ForwardRefFunction = (
    s: (props: unknown, ref?: unknown) => JSX.Element
  ) => {
    const returnFun = forwardRef
      ? // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (forwardRef as (s: unknown) => any)(s)
      : (props: Record<string, unknown>) => s(props);
    returnFun.displayName = displayName;
    return returnFun;
  };

  return gStyled(tag as never, addDisplayName as never) as never;
};

/** Light wrapper around goober's `styled`
 * @param tag - the tag or component you want to style
 * @param forwardRef - pass `React.forwardRef` to forward the ref to component being styled
 * @remarks In development, also adds `displyName` to styled components.
 */
export const styled = (
  import.meta.env.DEV ? devStyled : gStyled
) as StyledFunction;
