import React from "react";

import { mcn } from "@/utils";
import { Opacities, BorderRadius, Weights, styled } from "./theme";

interface StyledButtonProps {
  $disabled: boolean;
  $loading: boolean;
  $variant: "primary" | "secondary";
}

const StyledButton = styled("button", React.forwardRef)<StyledButtonProps>`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px 16px;

  user-select: none;
  font-size: 16px;
  line-height: 24px;
  font-family: inherit;
  color: ${({ theme, $variant }) =>
    $variant === "primary" ? theme.typography.onPrimary : theme.primary[700]};
  background-color: ${({ theme, $variant }) =>
    $variant === "primary" ? theme.primary[500] : theme.neutral[0]};
  border: 1px solid ${({ theme }) => theme.primary[700]};
  border-radius: ${BorderRadius.sm}px;

  cursor: ${({ $disabled, $loading }) =>
    $disabled ? "not-allowed" : $loading ? "unset" : "pointer"};

  ${({ $disabled }) => $disabled && `opacity: ${Opacities.disabled};`};
  ${({ $loading }) => $loading && `opacity: ${Opacities.loading};`};

  @media (hover: hover) {
    &:hover:not(.disable-events) {
      background-color: ${({ theme, $variant }) =>
        $variant === "primary" ? theme.primary[600] : theme.neutral[15]};
    }
  }

  &:active:not(.disable-events) {
    background-color: ${({ theme, $variant }) =>
      $variant === "primary" ? theme.primary[700] : theme.neutral[25]};
    transform: scaleX(0.99) scaleY(0.97);
  }
`;

const InvisibleSpan = styled("span")<{ $isVisible: boolean }>`
  opacity: ${({ $isVisible }) => ($isVisible ? 1 : 0)};
  font-weight: ${Weights.semi};
`;

const LoadingTitle = styled(InvisibleSpan)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`;

interface ButtonProps
  extends Omit<React.ComponentPropsWithoutRef<"button">, "children"> {
  loading?: boolean;
  title?: string;
  variant?: "primary" | "secondary";
  loadingTitle?: string;
}

export const Button = ({
  title,
  loading,
  loadingTitle,
  disabled,
  onClick,
  variant = "primary",
  className,
  ...props
}: ButtonProps) => {
  const showLoadingTitle = !!(loading && loadingTitle);
  const disableEvents = disabled || loading;

  return (
    <StyledButton
      $variant={variant}
      $disabled={!!disabled}
      $loading={!!loading}
      onClick={disableEvents ? (e) => e.preventDefault() : onClick}
      className={mcn(className, disableEvents && "disable-events")}
      {...props}
    >
      <InvisibleSpan
        $isVisible={!showLoadingTitle}
        aria-hidden={!!showLoadingTitle}
      >
        {title}
      </InvisibleSpan>

      <LoadingTitle
        $isVisible={showLoadingTitle}
        aria-hidden={!showLoadingTitle}
      >
        {loadingTitle}
      </LoadingTitle>
    </StyledButton>
  );
};
