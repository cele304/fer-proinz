import React from "react";
import { BorderRadius, styled, Shadows } from "./theme";
import { Paragraph } from "./typography";

const CardContainer = styled("div")<{ $elevated: boolean }>`
  display: flex;
  flex-direction: column;
  align-items: stretch;

  padding: 24px;
  background-color: ${({ theme }) => theme.surface};
  border: 1px solid ${({ theme }) => theme.border};
  border-radius: ${BorderRadius.md}px;
  ${({ $elevated }) => $elevated && Shadows.md};

  /* position: relative;
  a::after {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    content: "";
  } */
`;

interface CardProps extends React.ComponentPropsWithoutRef<"div"> {
  as?: string;
  elevated?: boolean;
}

export const Card = ({ elevated, children, ...props }: CardProps) => (
  <CardContainer $elevated={!!elevated} {...props}>
    {children}
  </CardContainer>
);

const StyledBadge = styled("div")<{ $colored: boolean }>`
  padding: 0 8px;

  background-color: ${({ theme, $colored }) =>
    $colored ? theme.primary[400] : theme.neutral[15]};
  border: 1px solid
    ${({ theme, $colored }) =>
      $colored ? theme.primary[600] : theme.neutral[50]};
  border-radius: 24px;

  white-space: nowrap;
`;

export const Badge = ({
  colored = false,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { colored?: boolean }) => (
  <StyledBadge $colored={colored} {...props}>
    <Paragraph size="sm" variant={colored ? "onPrimary" : "primary"}>
      {children}
    </Paragraph>
  </StyledBadge>
);
