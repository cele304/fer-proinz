import { styled, Weights } from "./theme";

interface BaseTypographyProps {
  center?: boolean;
  uppercase?: boolean;
}

// TODO make goober properly swallow these props
interface TypographyProps extends BaseTypographyProps {
  as?: string;
  size?: "sm" | "md" | "lg";
  variant?: "primary" | "secondary" | "colored" | "onPrimary";
  bold?: boolean;
}

const BaseTypography = styled("span")<BaseTypographyProps>`
  margin: 0;
  ${({ uppercase }) => uppercase && "text-transform: uppercase;"};
  ${({ center }) => center && "text-align: center;"}

  a {
    text-decoration: underline;
    transition: color 75ms, text-decoration-color 75ms;

    &:hover {
      text-decoration-color: ${({ theme }) => theme.typography.colored};
      color: ${({ theme }) => theme.typography.colored};
    }

    &:active {
      text-decoration-color: ${({ theme }) => theme.typography.coloredDark};
      color: ${({ theme }) => theme.typography.coloredDark};
    }
  }
`;

const headingSize = {
  sm: 20,
  md: 24,
  lg: 28,
};

const headingLineHeight = {
  sm: 28,
  md: 32,
  lg: 36,
};

export const Heading = styled(BaseTypography)<TypographyProps>`
  font-weight: ${Weights.bold};
  font-size: ${({ size = "md" }) => headingSize[size]}px;
  line-height: ${({ size = "md" }) => headingLineHeight[size]}px;

  a {
    text-decoration: underline;
    transition: color 75ms, text-decoration-color 75ms;
    text-decoration-color: transparent;

    &:hover {
      text-decoration-color: ${({ theme }) => theme.typography.colored};
      color: ${({ theme }) => theme.typography.colored};
    }

    &:active {
      text-decoration-color: ${({ theme }) => theme.typography.coloredDark};
      color: ${({ theme }) => theme.typography.coloredDark};
    }
  }
`;

const paragraphSize = {
  sm: 14,
  md: 16,
  lg: 18,
};

const paragraphLineHeight = {
  sm: 22,
  md: 24,
  lg: 28,
};

export const Paragraph = styled(BaseTypography)<TypographyProps>`
  font-size: ${({ size = "md" }) => paragraphSize[size]}px;
  line-height: ${({ size = "md" }) => paragraphLineHeight[size]}px;
  color: ${({ theme, variant = "primary" }) => theme.typography[variant]};
  font-weight: ${({ bold, variant }) =>
    bold
      ? Weights.bold
      : variant === "colored"
      ? Weights.semi
      : Weights.normal};
`;
