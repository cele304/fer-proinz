import { createGlobalStyles } from "goober/global";
import { Breakpoints } from "./theme";

const spacings = [0, 4, 8, 12, 16, 24, 32, 48, 64];

export const GlobalStyles = createGlobalStyles`
    body, html {
      height: 100%;
      background-color: ${({ theme }) => theme.background};
    }

    #root {
      min-width: 100%;
      min-height: 100%;

      display: flex;
      flex-direction: column;
      align-items: center;
  
      font-family: Inter, Avenir, Helvetica, Arial, sans-serif;
      font-size: 16px;
      line-height: 24px;
      color: ${({ theme }) => theme.typography.primary};

      font-synthesis: none;
      text-rendering: optimizeLegibility;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-text-size-adjust: 100%;
    }
    
    * {
      color: inherit;
      font-family: inherit;
      margin: 0;
      box-sizing: border-box;
    }
    
  
    :focus-visible {
      border-color: ${({ theme }) => theme.primary[100]} !important;
      box-shadow: 0 0 0 2px ${({ theme }) => theme.primary[75]} !important;
      outline: 2px dashed transparent;
    }
    
    svg {
      fill: currentColor;
    }
    
    hr {
      height: 1px;
      background-color: ${({ theme }) => theme.border};
      border: 0;
    }
    
    .hide-empty {
      &:empty {
        display: none;
      }
    }
    
    ${spacings.map((s) => `.m-${s} { margin: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.mt-${s} { margin-top: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.mb-${s} { margin-bottom: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.ml-${s} { margin-left: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.mr-${s} { margin-right: ${s}px; }`).join("\n")}

    ${spacings.map((s) => `.p-${s} { padding: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.pt-${s} { padding-top: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.pb-${s} { padding-bottom: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.pl-${s} { padding-left: ${s}px; }`).join("\n")}
    ${spacings.map((s) => `.pr-${s} { padding-right: ${s}px; }`).join("\n")}

    ${spacings.map((s) => `.g-${s} { gap: ${s}px; }`).join("\n")}

    .content-w { align-self: center; width: calc(100% - 32px); max-width: 900px; margin: 32px 16px 16px; }
    
    .flex-1 { flex: 1; }
    .flex-grow { flex-grow: 1; }
    .flex-shrink { flex-shrink: 1; }
    
    .d-flex { display: flex; }
    .flex-row { flex-direction: row; }
    .flex-column { flex-direction: column; }
    .flex-wrap { flex-wrap: wrap; }
    .align-items-start { align-items: start; }
    .align-items-center { align-items: center; }
    .align-items-end { align-items: end; }
    .justify-content-start { justify-content: start; }
    .justify-content-center { justify-content: center; }
    .justify-content-end { justify-content: end; }
    .justify-content-between { justify-content: space-between; }
    .justify-content-stretch { justify-content: stretch; }
    .align-self-stretch { align-self: stretch; }

    .text-truncate {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }

    .text-truncate-2 {
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      line-clamp: 2;
      -webkit-box-orient: vertical;
    }
    
    .d-none { display: none; }
    .d-block { display: block; }
    .d-flex { display: flex; }
    .d-contents { display: contents; }
    
    .minw-0 { min-width: 0; }
    
    @media (min-width: ${Breakpoints.md}px) {
      ${spacings.map((s) => `.md-m-${s} { margin: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.md-mt-${s} { margin-top: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.md-mb-${s} { margin-bottom: ${s}px; }`)
        .join("\n")}
      ${spacings.map((s) => `.md-ml-${s} { margin-left: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.md-mr-${s} { margin-right: ${s}px; }`).join("\n")}

      ${spacings.map((s) => `.md-p-${s} { padding: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.md-pt-${s} { padding-top: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.md-pb-${s} { padding-bottom: ${s}px; }`)
        .join("\n")}
      ${spacings.map((s) => `.md-pl-${s} { padding-left: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.md-pr-${s} { padding-right: ${s}px; }`)
        .join("\n")}

      ${spacings.map((s) => `.md-g-${s} { gap: ${s}px; }`).join("\n")}

      .md-d-flex { display: flex; }
      .md-flex-row { flex-direction: row; }
      .md-flex-column { flex-direction: column; }
      .md-flex-wrap { flex-wrap: wrap; }
      .md-align-items-start { align-items: start; }
      .md-align-items-center { align-items: center; }
      .md-align-items-end { align-items: end; }
      .md-justify-content-start { justify-content: start; }
      .md-justify-content-center { justify-content: center; }
      .md-justify-content-end { justify-content: end; }
      .md-justify-content-between { justify-content: space-between; }
      .md-justify-content-stretch { justify-content: stretch; }

      .md-d-none { display: none; }
      .md-d-block { display: block; }
      .md-d-flex { display: flex; }
    }

    @media (min-width: ${Breakpoints.lg}px) {
      ${spacings.map((s) => `.lg-m-${s} { margin: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.lg-mt-${s} { margin-top: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.lg-mb-${s} { margin-bottom: ${s}px; }`)
        .join("\n")}
      ${spacings.map((s) => `.lg-ml-${s} { margin-left: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.lg-mr-${s} { margin-right: ${s}px; }`).join("\n")}

      ${spacings.map((s) => `.lg-p-${s} { padding: ${s}px; }`).join("\n")}
      ${spacings.map((s) => `.lg-pt-${s} { padding-top: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.lg-pb-${s} { padding-bottom: ${s}px; }`)
        .join("\n")}
      ${spacings.map((s) => `.lg-pl-${s} { padding-left: ${s}px; }`).join("\n")}
      ${spacings
        .map((s) => `.lg-pr-${s} { padding-right: ${s}px; }`)
        .join("\n")}

      ${spacings.map((s) => `.lg-g-${s} { gap: ${s}px; }`).join("\n")}

      .lg-d-flex { display: flex; }
      .lg-flex-row { flex-direction: row; }
      .lg-flex-column { flex-direction: column; }
      .lg-flex-wrap { flex-wrap: wrap; }
      .lg-align-items-start { align-items: start; }
      .lg-align-items-center { align-items: center; }
      .lg-align-items-end { align-items: end; }
      .lg-justify-content-start { justify-content: start; }
      .lg-justify-content-center { justify-content: center; }
      .lg-justify-content-end { justify-content: end; }
      .lg-justify-content-between { justify-content: space-between; }
      .lg-justify-content-stretch { justify-content: stretch; }

      .lg-d-none { display: none; }
      .lg-d-block { display: block; }
      .lg-d-flex { display: flex; }
    }
  `;
