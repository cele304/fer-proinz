import {
  ComponentPropsWithoutRef,
  ComponentPropsWithRef,
  ReactNode,
} from "react";

import { BorderRadius, styled } from "./theme";
import { Icon } from "./icons";
import { Paragraph } from "./typography";

const StyledField = styled("div")`
  label {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  &:not(:last-child) {
    margin-bottom: 12px;
  }
`;

const Required = styled("span")`
  color: #c34343;
  font-weight: bold;
`;

interface FieldProps extends ComponentPropsWithRef<"div"> {
  label: string;
  required?: boolean;
}

/** Use to wrap a form input element. Adds a label and proper spacings to an element.
 * @example
 * ```tsx
 * const Form = () => (
 *  <div>
 *    <Field label="First name">
 *      <Input type="text" />
 *    </Field>
 *
 *    <Field label="Last name">
 *      <Input type="text" />
 *    </Field>
 *  </div>
 * );
 * ```
 */
export const Field = ({ label, required, children, ...props }: FieldProps) => (
  <StyledField {...props}>
    <Paragraph size="sm" as="label">
      <span className="d-flex">
        {label}
        {required && <Required>*</Required>}
      </span>
      {children}
    </Paragraph>
  </StyledField>
);

export const Input = styled("input")`
  font-size: 16px;
  line-height: 24px;
  border-radius: ${BorderRadius.sm}px;
  height: 42px;
  padding: 8px 12px;

  border: 1px solid ${({ theme }) => theme.border};
  background-color: ${({ theme }) => theme.surface};
  font-family: inherit;
`;

const SelectWrapper = styled("div")`
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding-right: 6px;
  height: 42px;

  background-color: ${({ theme }) => theme.surface};
  border-radius: ${BorderRadius.sm}px;
`;

const StyledSelect = styled("select")`
  appearance: none;
  background-color: transparent;
  border: 1px solid ${({ theme }) => theme.border};
  font-size: 16px;
  line-height: 24px;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 4px 32px 4px 8px;
  border-radius: ${BorderRadius.sm}px;
  font-family: inherit;
  outline-offset: 1px;
`;

interface SelectProps extends ComponentPropsWithoutRef<"select"> {
  children: ReactNode;
  name?: string;
}

export const Select = ({
  name,
  children,
  style,
  className,
  ...props
}: SelectProps) => {
  return (
    <SelectWrapper style={style} className={className}>
      <StyledSelect name={name} {...props}>
        {children}
      </StyledSelect>
      <Icon name="arrowDown" size={20} />
    </SelectWrapper>
  );
};
