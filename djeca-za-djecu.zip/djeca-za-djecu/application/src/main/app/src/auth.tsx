import {
  ComponentPropsWithoutRef,
  createContext,
  useContext,
  useEffect,
  useState,
} from "react";
import { API_HOST } from "./swr";

interface AuthContextValue {
  isLoggedIn: boolean;
  authToken: string | null;
  login: (
    email: string,
    password: string
  ) => Promise<void | "invalid_auth" | "unknown_error">;
  logout: () => Promise<boolean>;
  /** @deprecated use `logout` instead */
  forceLogout: () => void;
}

const AuthContext = createContext<AuthContextValue>(
  null as unknown as AuthContextValue
);

function hasLocalStorage() {
  const test = "test";
  try {
    localStorage.setItem(test, test);
    if (localStorage.getItem("test") !== "test")
      throw new Error("nolocalstorage");
    localStorage.removeItem(test);
    return true;
  } catch (e) {
    return false;
  }
}

export const AuthProvider = (
  props: Omit<ComponentPropsWithoutRef<typeof AuthContext.Provider>, "value">
) => {
  const [authToken, setAuthToken] = useState<string | null>(
    hasLocalStorage() ? localStorage.getItem("authToken") : null
  );

  // listen to storage changes, handles logging out in a different tab
  useEffect(() => {
    const handleLogout = (e: StorageEvent) => {
      if (e.key === "authToken") setAuthToken(e.newValue);
    };

    window.addEventListener("storage", handleLogout);
    () => window.removeEventListener("storage", handleLogout);
  });

  // synchronize localStorage to state
  useEffect(() => {
    if (hasLocalStorage())
      authToken
        ? localStorage.setItem("authToken", authToken)
        : localStorage.removeItem("authToken");
  }, [authToken]);

  const login = async (email: string, password: string) => {
    const url = new URL(API_HOST + "/korisnik/signin");
    url.searchParams.append("email", email);
    url.searchParams.append("lozinka", password);

    try {
      const res = await fetch(url, { method: "POST" });

      // this should be 403, but oh well
      if (res.status === 422) return "invalid_auth";
      if (!res.ok) return "unknown_error";

      const token = await res.text();

      setAuthToken(token);
    } catch (e) {
      return "unknown_error";
    }

    return;
  };

  const logout = async () => {
    setAuthToken(null);
    return true;
  };

  /** @deprecated - use `logout` */
  const forceLogout = logout;

  return (
    <AuthContext.Provider
      value={{ isLoggedIn: !!authToken, authToken, login, logout, forceLogout }}
      {...props}
    />
  );
};

export const useAuth = () => {
  const contextValue = useContext(AuthContext);

  if (!contextValue)
    throw new Error("useAuth hook called outside AuthProvider");

  return contextValue;
};
