import { useAuth } from "@/auth";
import { Redirect, Route, Switch } from "wouter";
import { Header } from "./features/header";
import { InterestArrangementForm } from "./features/interest_arrangement";
import {
  ListingPage,
  Listings,
  UnpublishedListings,
} from "./features/listings";
import { LoginForm } from "./features/login";
import { E404Message } from "./features/messages";
import { My } from "./features/my";
import { NewListingForm } from "./features/new_listing";
import { RegisterForm } from "./features/register";
import UserList from "./features/userList";

export const AppNavigator = () => {
  const { isLoggedIn } = useAuth();

  return isLoggedIn ? (
    <>
      <Header />

      <Switch>
        <Route path="/register">
          <Redirect to="/" />
        </Route>

        <Route path="/login">
          <Redirect to="/" />
        </Route>

        <Route path="/">
          <Listings />
        </Route>

        <Route path="/listings/:id/edit">
          <NewListingForm />
        </Route>

        <Route path="/listings/:id">
          <ListingPage />
        </Route>

        <Route path="/my">
          <My />
        </Route>

        <Route path="/my/new">
          <NewListingForm />
        </Route>

        <Route path="/users">
          <UserList />
        </Route>

        <Route path="/unpublished-listings">
          <UnpublishedListings />
        </Route>

        <Route path="/my-interests">
          <InterestArrangementForm />
        </Route>

        <Route path="/edit-profile">
          <RegisterForm />
        </Route>

        <Route>
          <E404Message />
        </Route>
      </Switch>
    </>
  ) : (
    <Switch>
      <Route path="/register">
        <RegisterForm />
      </Route>

      <Route path="/login">
        <LoginForm />
      </Route>

      <Route>
        <Redirect to="/login" />
      </Route>
    </Switch>
  );
};
