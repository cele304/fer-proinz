import "goober";

declare module "goober" {
  type color = import("./components/theme").color;

  export interface DefaultTheme {
    background: color;
    surface: color;
    border: color;
    scrim: color;

    typography: {
      primary: color;
      secondary: color;
      colored: color;
      coloredDark: color;
      onPrimary: color;
    };

    neutral: {
      0: color;
      15: color;
      25: color;
      50: color;
      75: color;
      85: color;
      100: color;
      200: color;
      300: color;
      400: color;
      500: color;
      600: color;
      700: color;
      800: color;
      900: color;
      1000: color;
    };

    primary: {
      15: color;
      25: color;
      50: color;
      75: color;
      85: color;
      100: color;
      200: color;
      300: color;
      400: color;
      500: color;
      600: color;
      700: color;
      800: color;
      900: color;
    };
  }
}
