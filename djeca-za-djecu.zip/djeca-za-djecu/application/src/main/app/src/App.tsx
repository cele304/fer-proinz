import "@csstools/normalize.css";
import React from "react";
import { setup as setupGoober } from "goober";
import { prefix } from "goober/prefixer";
import { shouldForwardProp } from "goober/should-forward-prop";

import { GlobalStyles } from "@/ui/globalStyles";
import { useTheme } from "@/ui/theme";
import { AppNavigator } from "@/navigation";
import { AuthProvider } from "./auth";
import { SwrProvider } from "./swr";

setupGoober(
  React.createElement,
  prefix,
  useTheme,
  shouldForwardProp((prop) => {
    return prop["0"] !== "$";
  })
);

function App() {
  return (
    <>
      <AuthProvider>
        <SwrProvider>
          <AppNavigator />
        </SwrProvider>
      </AuthProvider>
      {/* this must be last so goober doesn't override it with .go classnames */}
      <GlobalStyles />
    </>
  );
}

export default App;
