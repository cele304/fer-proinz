# Doniraj

## Opis i korištenje
Doniraj je web aplikacija preko koje korisnici mogu jednostavno donirati i preuzeti razne igračke i ostale stvari za djecu. Web aplikacija ima format oglasa koje korisnici mogu pregledavati i objavljivati.  
Trenutnu verziju aplikacije možete vidjeti na ovoj [poveznici](https://doniraj.duckdns.org).

### Pristup
Pristup aplikaciji je moguć samo korisnicima koji su se registrirali. Time želimo postići određen stupanj sigurnosti i mogućnost moderacije.  
Tako da prije nego što možete vidjeti objavljene oglase potrebno je napraviti korisnički račun pritiskom na gumb `Registiraj se` i onda u formi za registraciju popuniti **sve podatke**.

### Pregled oglasa
Oglasi su podjeljeni u dvije skupine:
  - novi oglasi (mlađi od 3 dana)
  - stariji oglasi (stariji od 3 dana)

Svaki oglas uz naslov, opis i sliku ima i podatke i o tome za koju dob i spol djetata je predmet namjenjen i podatak o stanju predmeta.

### Objava oglasa
Objava novih oglasa trenutno nije podržana.
___
## Dokumentacija
Sva potrebna dokumentacija se može pronaći u ovom [dokumentu](PROGI_2022_Team4Avenue_v1_0.pdf).  
LaTeX kod iz kojega je dokumentacija izgenerirana se može pronaći u direktoriju [Dokumentcija](#https://gitlab.com/team4avenue/djeca-za-djecu/-/tree/master/dokumentacija).
___

## Pokretanje aplikacije

Aplikaciju je moguće pokrenuti na dva načina. Jedan je buildanje projekta koristeći maven i pokretanje pomoću jave, a drugi je koristeći `docke-compose`.

### a) Maven
#### Preduvjeti
- Instaliran `maven`
- Instaliran `java jdk 11` ili više
#### Pokretanje pomoću mavena i jave 

1. Otvoriti terminal u `application` direktoriju
2. `mvn clean`
3. `mvn package`
4. `java -jar target/*.jar`
- Nakon što se aplikacije pokrene može joj se pristupiti na [http://localhost:8080](http://localhost:8080).

### b) Docker-compose
### Preduvjeti

- Instaliran `docker`
- Instaliran `docker-compose`
### Pokretanje pomoću docker-compose
1. Otvoriti terminal u korijenskom direktoriju projekta
2. Pokrenuti ove dvije naredbe:
```bash
sudo docker-compose build
sudo docker-compose up
```
Za zaustavljanje aplikacije pokrenuti naredbu:  
 ```bash
 sudo docker-compose stop
 ```